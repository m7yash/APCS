import org.junit.*;

import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;


/**
 * Test for the complex number class.
 * 
 * testConstructor1Param - test the 1 parameter constructor
 * testConstructor2Param - test the 2 parameter constructor
 * testAddRealAndComplexNum - addition of a complex number with a real number
 * testAdd2ComplexNums - addition of two complex numbers
 * testMultiply2ComplexNums - multiplication of two complex numbers
 * testMultiplyRealAndComplexNum - multiplication of a complex number with a
 * real number testAbsoluteValue - absolute value of a complex number
 *
 * @author TODO Your Name
 * @version TODO Date
 * @author Period: TODO Your Period
 * @author Assignment: JMCh09Ex17_Complex
 *
 * @author Sources: TODO List collaborators
 */
public class ComplexJUTest extends junit.framework.TestCase
{
    @Test
    public void testConstructor1Param()
    {
        // TODO complete test
        Complex c1 = new Complex( 1, 2 );
        assertEquals( "1.0 + 2.0i", c1.toString() );
    }


    @Test
    public void testConstructor2Param()
    {
        // TODO complete test
        Complex c2 = new Complex( 1 );
        assertEquals( "1.0 + 0.0i", c2.toString() );
    }


    @Test
    public void testAddRealAndComplexNum()
    {
        // TODO complete test
        Complex c3 = new Complex( 1, 2 );
        assertEquals( "2.0 + 2.0i", c3.add( 1.0 ).toString() );
    }


    @Test
    public void testAdd2ComplexNums()
    {
        Complex c4 = new Complex( 1, 2 );
        Complex c5 = new Complex( 3, 5 );
        assertEquals( "4.0 + 7.0i", c4.add( c5 ).toString() );
    }


    @Test
    public void testMultiply2ComplexNums()
    {
        Complex c6 = new Complex( 1, 2 );
        Complex c7 = new Complex( 3, 4 );
        assertEquals( "-5.0 + 10.0i", c6.multiply( c7 ).toString() );
    }


    @Test
    public void testMultiplyRealAndComplexNum()
    {
        // TODO complete test
        Complex c8 = new Complex( 1, 2 );
        assertEquals( "3.0 + 6.0i", c8.multiply( 3 ).toString() );
    }


    @Test
    public void testAbsoluteValue()
    {
        // TODO complete test
        Complex c9 = new Complex( 3, 4 );
        assertEquals( 5.0, c9.abs() );
    }


    public static junit.framework.Test suite()
    {
        return new JUnit4TestAdapter( ComplexJUTest.class );
    }


    public static void main( String args[] )
    {
        org.junit.runner.JUnitCore.main( "ComplexJUTest" );
    }
}
