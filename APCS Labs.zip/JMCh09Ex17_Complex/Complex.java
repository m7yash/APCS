/**
 * Represents a complex number of the form a + bi. Provides methods for adding,
 * multiplying and calculating the absolute value.
 *
 * @author Yash Mishra
 * @version 10/2/19
 * @author Period: 4
 * @author Assignment: JMCh09Ex17_Complex
 *
 * @author Sources: none
 */
public class Complex
{
    // TODO instance variables
    private double a;

    private double b;


    // TODO Constructors

    /**
     * 
     * @param a is the real number
     * @param b is the imaginary number
     */
    
    public Complex( double a, double b )
    {
        this.a = a;
        this.b = b;
    }

    
    /**
     * 
     * @param a is the real number
     */

    public Complex( double a )
    {
        this( a, 0.0 );
    }


    // TODO Methods

    /**
     * 
     * finds the magnitude of the complex numbers
     * @return the magnitude
     */
    
    public double abs()
    {

        double aSquared = a * a;
        double bSquared = b * b;
        double root = Math.sqrt( aSquared + bSquared );

        return root;

    }


    /**
     * 
     * adds the two real numbers and the two imaginary numbers
     * @param other is another complex number
     * @return sum os the sum of the complex numbers
     */
    
    public Complex add( Complex other )
    {
        double aSum = a + other.a;
        double bSum = b + other.b;

        Complex sum = new Complex( aSum, bSum );

        return sum;

    }

    /**
     * 
     * adds the real number to another real number
     * @param n is a real number
     * @return sum of the complex number with a real number
     */

    public Complex add( double n )
    {
        double aSum = a + n;
        double bSum = b;

        Complex sum = new Complex( aSum, bSum );

        return sum;
    }

    /**
     * 
     * multiplies two complex numbers
     * @param other is another Complex number
     * @return the multiplication of the complex numbers
     */
    
    public Complex multiply( Complex other )
    {
        double firstTerm = a * other.a;
        double secondTerm = b * other.b;
        double thirdTerm = a * other.b;
        double fourthTerm = b * other.a;

        Complex multiplication = new Complex( firstTerm - secondTerm,
            thirdTerm + fourthTerm );

        return multiplication;
    }

    /**
     * 
     * multiplies a complex number with a real number
     * @param n is a real number
     * @return multiplication of a complex numer and a real number
     */

    public Complex multiply( double n )
    {
        Complex multiplication = new Complex( a * n, b * n );

        return multiplication;
    }

    /**
     * 
     * expresses the complex number in the form of a string
     * @return a string in the form of a + bi
     */
    
    public String toString()
    {
        return a + " + " + b + "i";
    }
}
