import java.util.Stack;


/**
 * 
 *  a small browser's model
 *
 *  @author  Yash Mishra
 *  @version Jan 18, 2020
 *  @author  Period: 4
 *  @author  Assignment: JMCh21_3Browsing
 *
 *  @author  Sources: 
 */
public class BrowserModel
{
    private BrowserView view;

    private Stack<Integer> backStk;
    
    private Stack<Integer> forwardStk;

    private int topLine;

    // TODO complete constructor
    /**
     * updates view to 0
     * 
     * @param view
     *            is the user's view
     */
    public BrowserModel( BrowserView view )
    {
        this.view = view;
        view.update( 0 );
        backStk = new Stack<Integer>();
        forwardStk = new Stack<Integer>();
    }


    // TODO complete methods
    /**
     * 
     * will shift the view to n's line
     * 
     * @param n
     *            is the line to shift to
     */
    public void followLink( int n )
    {
        backStk.push( topLine );
        topLine = n;
        view.update( topLine );
        removeForward();
    }


    /**
     * 
     * takes the user back to line 0
     */
    public void home()
    {
        backStk.push( topLine );
        topLine = 0;
        view.update( topLine );
        removeForward();
    }


    /**
     * 
     * sees if backStk isn't empty
     * 
     * @return if it's not empty
     */

    public boolean hasBack()
    {
        return !backStk.isEmpty();
    }


    /**
     * 
     * goes to previous page
     */
    public void back()
    {
        forwardStk.push( topLine );
        if ( hasBack() )
        {
            topLine = backStk.pop();
            view.update( topLine );
        }
        else
        {
            System.out.println( "error" );
        }
    }


    /**
     * 
     * sees if fwdStack isn't empty
     * 
     * @return if it's empty
     */
    public boolean hasForward()
    {
        return !forwardStk.isEmpty();
    }


    /**
     * 
     * moves to the next page, opposite of back()
     */
    public void forward()
    {
        backStk.push( topLine );
        if ( hasForward() )
        {
            topLine = forwardStk.pop();
            view.update( topLine );
        }
        else
        {
            System.out.println( "error" );
        }
    }


    /**
     * 
     * helper method for removing forward availability
     */
    public void removeForward()
    {
        forwardStk.removeAllElements();
    }


    // The following are for test purposes only
    /**
     * 
     * get method
     * 
     * @return backStk
     */
    public Stack<Integer> getBackStk()
    {
        return backStk;
    }


    /**
     * 
     * get method
     * 
     * @return forwardStk
     */
    public Stack<Integer> getForwardStk()
    {
        return forwardStk;
    }


    /**
     * 
     * get method
     * 
     * @return topLine
     */
    public int getTopLine()
    {
        return topLine;
    }
}
