public class RamblecsDictionary
{
    public String words[] = 
    {
       "ABACK",
       "ABASE",
       "ABASH",
       "ZIPPY",
       "ZLOTY",
       "ZONE",
       "ZOO",
       "ZOOM",
    };
}
