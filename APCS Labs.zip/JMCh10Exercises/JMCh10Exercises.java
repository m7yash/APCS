import java.util.*;


/**
 * Java Methods Chapter 10 Exercises 2, 6 - 11, 14 - 15, 20 & 22
 * 
 * @author Yash
 * @version 10/14/19
 * 
 * @author Period - 4
 * @author Assignment - Ch10Exercises
 * 
 * @author Sources - none
 */
public class JMCh10Exercises
{
    Scanner scan;

    /**
     * Constructs a Scanner for input from the console.
     */
    public JMCh10Exercises()
    {
        scan = new Scanner( System.in );
    }


    /**
     * Constructs a Scanner to evaluate passed input (used for testing).
     * 
     * @param str
     *            input for the various methods
     */
    public JMCh10Exercises( String str )
    {
        scan = new Scanner( str );
    }


    // 10-2(a)
    public boolean endsWithStar( String s )
    {
        if ( s.length() != 0 && s.charAt( s.length() - 1 ) == '*' )
        {
            return true;
        }
        return false;
    }


    // 10-2(b)
    public boolean endsWith2Stars( String s )
    {
        // TODO complete method

        if ( s.length() >= 2 )
        {
            if ( s.charAt( s.length() - 1 ) == '*' )
            {
                if ( s.charAt( s.length() - 2 ) == '*' )
                {
                    return true;
                }
            }
        }
        return false;
    }


    // 10-6
    public String scroll( String s )
    {
        // TODO complete method

        char firstLetter = s.charAt( 0 );
        String newString = s.substring( 1 ) + firstLetter;

        return newString; // FIX THIS!!!
    }


    // 10-7
    public String convertName( String name )
    {
        // TODO complete method

        String first = "";
        String last = "";

        int x = 0;
        for ( int i = 0; i < name.length(); i++ )
        {
            if ( name.charAt( i ) != ',' )
            {
                last += name.charAt( i );
            }
            else
            {
                x = i + 2;
                break;
            }
        }
        
        for (int n = x; n < name.length(); n++)
        {
            first += name.charAt(n);
        }

        return first + " " + last; // FIX THIS!!!
    }


    // 10-8
    public String negate( String str )
    {
        // TODO complete method
        
        String a = str.replace( '0', 'x' );
        String b = a.replace( '1', '0' );
        String c = b.replace( 'x', '1' );

        return c; // FIX THIS!!!
    }


    // 10-9
    public boolean isConstant( String s )
    {
        // TODO complete method
        
        String start = s;
        
        char myChar = s.charAt(0);

        s = s.substring( 1 ) + myChar;
        
        if (s.equals(start))
        {
            return true;
        }
        
        return false; // FIX THIS!!!
    }


    // 10-10
    public String removeComment( String str )
    {
        // TODO complete method
        
        if (str.contains("/*") && str.contains( "*/" ))
        {

            String firstPart = str.substring( 0, str.indexOf("/*"));

            String secondPart = str.substring( str.indexOf("*/") + 2);    
        
            return firstPart + secondPart;
        }
        else
        {
            return str;
        }
    }


    // 10-11
    public String cutOut( String s, String s2 )
    {
        // TODO complete method
        
        String firstPart = "";
        String secondPart = "";
        
        if (s.contains( s2 ))
        {
            firstPart += s.substring( 0, s.indexOf( s2 ));
            secondPart += s.substring( s.indexOf( s2 ) + s2.length() );
        }

        return firstPart + secondPart; // FIX THIS!!!
    }


    // 10-14
    public String removeHtmlTags( String str )
    {
        // TODO complete method

        String output = "";

        for ( int i = 0; i < str.length(); i++ )
        {
            if ( str.charAt( i ) == '<' )
            {
                for ( int x = i; str.charAt( x ) != '>'; x++ )
                {
                    i = x + 1;
                }
            }
            else
            {
                output += str.charAt( i );
            }
        }

        return output;
    }


    // 10-15
    public boolean onlyDigits( String s )
    {
        for ( int i = 0; ( i <= s.length() )
            && ( Character.isDigit( s.charAt( i ) ) == true ); i++ )
        {
            if ( i == s.length() - 1 )
            {
                return true;
            }
        }
        return false;
    }


    // 10-20
    public static boolean isValidISBN( String isbn )
    {
        // TODO complete method
        char current;
        int isbnId = 0;
        for (int i = 0; i < isbn.length(); i++)
        {
            current = isbn.charAt(i);
            if (current == 'x') {
                isbnId += 10 * (isbn.length() - i);
            }
            isbnId += Character.digit(current, 10) * (isbn.length() - i);
        }
        if (isbnId % 11 == 0)
        {
            return true;
        }
        return false;
    }


    // 10-22
    public String shuffle( String s )
    {
        
        StringBuffer x = new StringBuffer(s);
        
        int n = x.length();
        int y;
        char current;
        while (n > 1)
        {
            y = (int)(n*(Math.random()));
            current = x.charAt(y);
            x.setCharAt(y, x.charAt(n - 1));
            x.setCharAt(n - 1, current);
            n--;
        }
        
        String output = new String(x);

        return output; // FIX THIS!!!
    }


    /**
     * Testing method: instantiates a Ch18Ex1to5 object and then invokes each
     * method.
     * 
     * @param args
     *            command line parameters (not used)
     */
    public static void main( String[] args )
    {
        Scanner kbd = new Scanner( System.in );
        boolean done = false;

        JMCh10Exercises exercise = new JMCh10Exercises();

        do
        {
            System.out.println();
            System.out.println();
            System.out.println( "Make a selection" );
            System.out.println();
            System.out.println( "   (1) 10-2(a) endsWithStar( String s )" );
            System.out.println( "   (2) 10-2(b) endsWith2Stars( String s )" );
            System.out.println( "   (3) 10-6 scroll( String s )" );
            System.out.println( "   (4) 10-7 convertName( String name )" );
            System.out.println( "   (5) 10-8 negate( String str )" );
            System.out.println( "   (6) 10-9 isConstant( String s )" );
            System.out.println( "   (7) 10-10 removeComment( String str )" );
            System.out.println( "   (8) 10-11 cutOut( String s, String s2 )" );
            System.out.println( "   (9) 10-14 removeHtmlTags( String str )" );
            System.out.println( "   (A) 10-15 onlyDigits( String s )" );
            System.out.println( "   (B) 10-20 isValidISBN( String isbn )" );
            System.out.println( "   (C) 10-22 shuffle( String s )" );
            System.out.println( "   (Q) Quit" );
            System.out.println();
            System.out.print( "Enter a choice:  " );
            String response = kbd.nextLine();

            if ( response.length() > 0 )
            {
                System.out.println();

                switch ( response.charAt( 0 ) )
                {
                    case '1':
                        String end1Star = "**endsWith**Star*";
                        System.out.println( "endsWithStar(" + end1Star + ") = "
                            + exercise.endsWithStar( end1Star ) );
                        String ends0Star = "**endsWith**Star*No";
                        System.out.println( "endsWithStar(" + ends0Star
                            + ") = " + exercise.endsWithStar( ends0Star ) );
                        break;
                    case '2':
                        String end2Str = "**endsWith**2Stars**";
                        System.out.println( "endsWith2Stars(" + end2Str
                            + ") = " + exercise.endsWith2Stars( end2Str ) );
                        String endsWith1Star = "**endsWith**2Stars*";
                        System.out.println(
                            "endsWith2Stars(" + endsWith1Star + ") = "
                                + exercise.endsWith2Stars( endsWith1Star ) );
                        break;
                    case '3':
                        String scrollStr = "bdfhjlnprtvxz";
                        System.out
                            .println( "scroll(\"" + scrollStr + "\") --> "
                                + "\"" + exercise.scroll( scrollStr ) + "\"" );
                        break;
                    case '4':
                        String convStr = "von Neumann, John";
                        System.out.println(
                            "convertName(\"" + convStr + "\") --> " + "\""
                                + exercise.convertName( convStr ) + "\"" );
                        break;
                    case '5':
                        String negStr = "1001110001010101110";
                        System.out.println( "negate(\"" + negStr + "\") --> "
                            + "\"" + exercise.negate( negStr ) + "\"" );
                        break;
                    case '6':
                        String constStr1 = "0000000000000000000";
                        String constStr2 = "1001110001010101110";
                        System.out.println( "isConstant(\"" + constStr1
                            + "\") = " + exercise.isConstant( constStr1 ) );
                        System.out.println( "isConstant(\"" + constStr2
                            + "\") = " + exercise.isConstant( constStr2 ) );
                        break;
                    case '7':
                        String comment = "/* this should be gone */ int a = 0;";
                        String notComment = "/* this should stay /* int a = 0;";
                        System.out.println(
                            "removeComment(\"" + comment + "\") --> " + "\""
                                + exercise.removeComment( comment ) + "\"" );
                        System.out.println( "removeComment(\"" + notComment
                            + "\") --> " + "\""
                            + exercise.removeComment( notComment ) + "\"" );
                        break;
                    case '8':
                        String cutstr = "Hi-ho, hi-ho";
                        String cutOutstr = "-ho";
                        System.out.println( "cutOut(\"" + cutstr + "\", \""
                            + cutOutstr + "\") --> " + "\""
                            + exercise.cutOut( cutstr, cutOutstr ) + "\"" );
                        break;
                    case '9':
                        String htmlStr = "Strings are <b>immutable</b>";
                        System.out.println(
                            "removeHtmlTags(\"" + htmlStr + "\") --> " + "\""
                                + exercise.removeHtmlTags( htmlStr ) + "\"" );
                        break;
                    case 'A':
                    case 'a':
                        String digitStr = "123456789";
                        String dStr = "1234V5678";
                        System.out.println( "onlyDigits(\"" + digitStr
                            + "\") = " + exercise.onlyDigits( digitStr ) );
                        System.out.println( "onlyDigits(\"" + dStr + "\") = "
                            + exercise.onlyDigits( dStr ) );
                        break;
                    case 'B':
                    case 'b':
                        String validISBN = "096548534X";
                        String invalidISBN = "1234567890";
                        System.out.println( "isValidISBN(\"" + validISBN
                            + "\") = " + exercise.isValidISBN( validISBN ) );
                        System.out.println( "isValidISBN(\"" + invalidISBN
                            + "\") = " + exercise.isValidISBN( invalidISBN ) );
                        break;
                    case 'C':
                    case 'c':
                        String str = "The quick brown fox";
                        System.out.println( "shuffle(\"" + str + "\") --> "
                            + "\"" + exercise.shuffle( str ) + "\"" );
                        System.out.println( "shuffle(\"" + str + "\") --> "
                            + "\"" + exercise.shuffle( str ) + "\"" );
                        break;
                    default:
                        if ( response.toLowerCase().charAt( 0 ) == 'q' )
                        {
                            done = true;
                        }
                        else
                        {
                            System.out.print( "Invalid Choice" );
                        }
                        break;
                }
            }
        } while ( !done );
        System.out.println( "Goodbye!" );
    }
}
