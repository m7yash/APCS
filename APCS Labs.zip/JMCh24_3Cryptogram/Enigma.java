//removed import statement because webcat was angry

/**
 * Decodes encrypted messages
 * 
 * @author Yash Mishra
 * @version 2/14/20
 * 
 * @author Period - 4
 * @author Assignment - JM 24.3 Lab: Cryptogram Solver
 * 
 * @author Sources -
 */
public class Enigma
{
    private char[] lookupTable;

    /**
     * is the constructor for this class
     * @param numLetters is the number of letters
     */
    public Enigma( int numLetters )
    {
        // TODO complete constructor
        lookupTable = new char[numLetters];
    }

    /**
     * 
     * replaces the lookuptable entry with the character at the index
     * @param index is the index to replace it
     * @param ch is the character to put
     */
    public void setSubstitution( int index, char ch )
    {
        // TODO complete method
        lookupTable[index] = ch;
    }

    /**
     * 
     * decodes (decrypts) the text
     * @param text to decrypt
     * @return decrypted version
     */
    public String decode( String text )
    {
        StringBuffer buffer = new StringBuffer( text.length() );
        int iterator = 0;
        while ( iterator < text.length() )
        {
            char ch = text.charAt( iterator );
            if ( Character.isLetter( ch ) )
                if ( Character.isUpperCase( ch ) )
                {
                    char temp = lookupTable[ch - 'A'];
                    buffer.append( temp );
                }
                else
                {
                    ch = Character.toUpperCase( ch );
                    char temp = lookupTable[ch - 'A'];
                    buffer.append( Character.toLowerCase( temp ) );
                }
            else
            {
                buffer.append( text.charAt( iterator ) );
            }
            iterator++;
        }
        return buffer.toString();
    }

    /**
     * 
     * gets the hints for the text
     * @param text to get hints for
     * @param lettersByFrequency is the letters by frequency
     * @return the hints in string version
     */
    public String getHints( String text, String lettersByFrequency )
    {
        // TODO complete method
        StringBuffer toReturn = new StringBuffer();
        int[] counts = countLetters( text );
        for ( int i = 0; i < counts.length; i++ )
        {
            int c = 0;
            for ( int j = 0; j < counts.length; j++ )
            {
                int a = counts[i];
                int b = counts[j];
                if ( b < a || a == b && i > j )
                {
                    c++;
                }
            }
            toReturn.append( lettersByFrequency.charAt( c ) );
        }
        return toReturn.toString();
    }

    /**
     * 
     * counts the number of letters, uses lookuptable
     * @param text to ocunt
     * @return letters number
     */
    private int[] countLetters( String text )
    {
        int[] counts = new int[lookupTable.length];
        int iterator = 0;
        while ( iterator < text.length() )
        {
            if ( Character.isLetter( text.charAt( iterator ) ) )
            {
                counts[Character.toUpperCase( text.charAt( iterator ) )
                    - 'A']++;
            }
            iterator++;
        }
        return counts;
    }

    // *************************************************************
    // For test purposes only
    // not to be used in solution implementation

    /**
     * 
     * accessor method
     * @return array lookuptable
     */
    public char[] getLookupTable()
    {
        return lookupTable;
    }

    /**
     * 
     * accesssor method
     * @param text to count
     * @return number of letters
     */
    public int[] getCountLetters( String text )
    {
        return countLetters( text );
    }

}