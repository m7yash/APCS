import java.util.*;


/**
 * This is the class SearchEngine for the Giggle Search Engine. It has several
 * functions like adding.
 * 
 * @author Yash Mishra
 * @version 2/22/20
 * 
 * @author Period - 4
 * @author Assignment - JM24.6 - Search Engine
 * 
 * @author Sources - 
 */
public class SearchEngine
{
    // Instance variable(s)
    private String myURL; // holds the name for the "url" (file name)

    private Map<String, List<String>> myIndex; // holds the word index

    // Constructor(s)
    /**
     * creates search engine
     * @param url is the URL that you hold in the myURL String
     */
    public SearchEngine( String url )
    {
        myURL = url;
        myIndex = new HashMap( 20000 );
    }

    // Methods
    /**
     * 
     * accessor method for the url
     * @return the myURL string
     */
    public String getURL()
    {
        return myURL;
    }
    /**
     * 
     * adds the line
     * @param line is the input to add to myIndex
     */
    public void add( String line )
    {
        for ( String s : parseWords( line ) )
        {
            if ( !myIndex.containsKey( s ) )
            {
                myIndex.put( s, new LinkedList<String>() );
            }
            myIndex.get( s ).add( line );
        }
    }
    /**
     * 
     * returns the "hits" based on what word is inputted
     * @param word to get the amount of "hits" for
     * @return number of "hits"
     */
    public List<String> getHits( String word )
    {
        return myIndex.get( word );
    }
    /**
     * 
     * parses the words given in a line
     * @param line to parse words in
     * @return a new TreeSet<String> called words
     */
    private Set<String> parseWords( String line )
    {
        TreeSet<String> words = new TreeSet<String>();
        for ( String s : line.split( "\\W+" ) )
        {
            if ( !s.isEmpty() )
            {
                s = s.toLowerCase();
                words.add( s );
            }
        }
        return words;
    }
    // *************************************************************
    // For test purposes only
    // not to be used in solution implementation
    /**
     * 
     * accessor method for index
     * @return index for test purposes
     */
    public Map<String, List<String>> getIndex()
    {
        return myIndex;
    }
}