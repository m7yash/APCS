import java.util.NoSuchElementException;


/**
 * Implements a singly-linked list with a tail.
 *
 * @author Yash Mishra
 * @version 12/13/19
 * @author Period: 4
 * @author Assignment: JMCh20_5LinkedListWithTail
 *
 * @author Sources: none
 */
public class LinkedListWithTail<E>
{
    private ListNode<E> head, tail;

    /**
     * Constructs an empty list.
     */
    public LinkedListWithTail()
    {
        // TODO: complete method
        head = null;
        tail = null;
    }


    /**
     * Returns true if this list is empty; otherwise returns false.
     * 
     * @return true if this list contains no elements false otherwise
     */
    public boolean isEmpty()
    {
        // TODO: complete method
        if ( head == null )
        {
            return true;
        }

        return false;
    }


    /**
     * Retrieves, but does not remove, the head (first element) of this list.
     * 
     * @return the head of this list, or null if this list is empty
     */
    public E peek()
    {
        // TODO: complete method
        if ( isEmpty() )
        {
            return null;
        }
        else
        {
            return head.getValue();            
        }
    }


    /**
     * Appends the specified element to the end of this list.
     * 
     * @param obj
     *            - element to be appended to this list
     * @return true if this collection changed as a result of the call
     */
    public boolean add( E obj )
    {
        // TODO: complete method
        
        ListNode<E> nullNode = new ListNode<E>(obj, null);

        if ( isEmpty() )
           
        {
            head = new ListNode<E>( obj, tail );
            tail = head;
            return true;
        }
        else
        {
            tail.setNext( nullNode );
            tail = nullNode;
            return true;
        }
    }


    /**
     * Retrieves and removes the head (first element) of this list.
     * 
     * @return the head of this list
     * @throws NoSuchElementException
     *             - if this list is empty
     */
    public E remove()
    {
        // TODO: complete method
        if ( isEmpty() )
        {
            throw new NoSuchElementException();
        }
        E toReturn = head.getValue();
        head = head.getNext();
        return toReturn;

    }


    /**
     * Exercise 20.12
     * 
     * Appends otherList at the end of this list. Append should work in O(1)
     * time, regardless of the list sizes, and it should work properly when
     * either list is empty or both list are empty
     * 
     * @param otherList
     *            list to be appended to the end of this list
     */
    public void append( LinkedListWithTail<E> otherList )
    {
        // TODO: complete method

        ListNode<E> otherHead = otherList.head;

        if ( isEmpty() )
        {
            head = otherList.head;
        }
        else if (otherList != null)
        {
            tail.setNext( otherHead );
        }

    }


    /**
     * *** FOR TESTING PURPOSES ONLY ***
     *
     * Returns a string representation of this list.
     * 
     * @return a string representation of this list.
     */
    public String toString()
    {
        String str = "[", separator = "";

        for ( ListNode<E> node = head; node != null; node = node.getNext() )
        {
            str += ( separator + node.getValue() );
            separator = ", ";
        }

        return str + "]";
    }
}
