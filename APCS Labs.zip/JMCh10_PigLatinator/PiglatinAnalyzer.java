import java.util.Scanner;


/**
 * Converts English to pigLatin
 * 
 * @author Yash Mishra
 * @version 10/18/19
 * 
 * @author Period - 4
 * @author Assignment - PigLatinator
 * 
 * @author Sources - none
 */
public class PiglatinAnalyzer
{
    private String text;

    // Constructor: saves the text string
    public PiglatinAnalyzer( String text )
    {
        // TODO add constructor code
        this.text = text;
    }


    /**
     * Converts a string to it piglatin form according to the following rules:
     * a. If there are no vowels in text, then pigLatinWord is just text + "ay".
     * (There are ten vowels: 'a', 'e', 'i', 'o', and 'u', and their uppercase
     * counterparts.) b. Else, if text begins with a vowel, then pigLatinWord is
     * just text + "yay". c. Otherwise (if text has a vowel in it and yet
     * doesn't start with a vowel), then pigLatinWord is end + start + "ay",
     * where end and start are defined as follows: 1. Let start be all of text
     * up to (but not including) its first vowel. 2. Let end be all of text from
     * its first vowel on. 3. But, if text is capitalized, then capitalize end
     * and "uncapitalize" start.
     *
     * @return piglatin version of text as a String
     */
    public String phraseToPigLatin()
    {
        String phraseToTranslate = text;
        String translation = "";
        int start;
        int end;
        char c;
        String finalCharacterString;
        for ( int x = 0; x < text.length(); x++ )
        {
            start = -1;
            end = phraseToTranslate.length();
            finalCharacterString = "";
            for ( int i = 0; i < phraseToTranslate.length(); i++ )
            {
                c = phraseToTranslate.charAt( i );
                if ( Character.isLetter( c ) && start == -1 )
                {
                    start = i;
                }
                else if ( !Character.isLetter( c ) && start != -1 )
                {
                    end = i;
                    finalCharacterString = Character.toString( c );
                    break;
                }
            }
            if ( start == -1 )
            {
                translation = translation + phraseToTranslate;
                break;
            }
            translation = translation + phraseToTranslate.substring( 0, start )
                + wordToPigLatin( phraseToTranslate.substring( start, end ) )
                + finalCharacterString;
            if ( end == phraseToTranslate.length() )
            {
                break;
            }
            phraseToTranslate = phraseToTranslate.substring( end + 1 );
        }

        return translation;
    }


    /**
     * Converts an "english" word to its piglatin form
     *
     * @param text
     *            a string representing an english word
     * @return piglatin form of the english word
     */
    public String wordToPigLatin( String text )
    {
        String pigLatinWord = text;
        int increment = 0;
        while ( increment < text.length()
            && "aeiou".indexOf( text.charAt( increment ) ) == -1
            && "AEIOU".indexOf( text.charAt( increment ) ) == -1 )
        {
            increment++;
        }
        if ( increment == 0 )
        {
            pigLatinWord += "yay";
        }
        else if ( increment == text.length() )
        {
            pigLatinWord += "ay";
        }
        else
        {
            pigLatinWord = text.substring( increment )
                + text.substring( 0, increment ) + "ay";
            if ( Character.isUpperCase( text.charAt( 0 ) ) == true )
            {
                pigLatinWord = Character
                    .toUpperCase( pigLatinWord.charAt( 0 ) )
                    + pigLatinWord.substring( 1 ).toLowerCase();
            }

        }
        return pigLatinWord;
    }
}
