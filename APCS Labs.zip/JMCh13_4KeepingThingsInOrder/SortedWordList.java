
/**
 * Implements a sorted list of words
 * 
 * @author Yash Mishra
 * @version 11/27/19
 * 
 * @author Period - 4
 * @author Assignment - Java Methods 13.4 Lab: Keeping Things in Order
 * 
 * @author Sources - none
 */
public class SortedWordList extends java.util.ArrayList<String>
{
    // TODO complete methods

    /**
     * no args constructor
     */

    public SortedWordList()
    {
        super();
    }


    /**
     * constructor with argument
     * 
     * @param myCapacity
     *            is capacity for constructor
     */

    public SortedWordList( int myCapacity )
    {
        super( myCapacity );
    }


    /**
     * 
     * sees if string is contained
     * 
     * @param s
     *            is string
     * @return true or false depending on if the string is there
     */
    public boolean contains( String s )
    {
        return ( indexOf( s ) != -1 );
    }


    /**
     * 
     * finds the index of string
     * 
     * @param s
     *            is the string
     * @return -1 if not there or if right < left, else returns index
     */
    public int indexOf( String s )
    {
        int left = 0;
        int right = size() - 1;

        if ( right < left )
        {
            return -1;
        }

        while ( left <= right )
        {
            int middle = ( left + right ) / 2;

            if ( s.compareToIgnoreCase( get( middle ) ) < 0 )
            {
                right = middle - 1;
            }
            else if ( s.compareToIgnoreCase( get( middle ) ) > 0 )
            {
                left = middle + 1;
            }
            else
            {
                return middle;
            }
        }

        return -1;
    }


    /**
     * @param i
     *            is index
     * @param word
     *            is string
     * 
     * @return the setting or illegalargexception
     */
    public String set( int i, String word )
    {
        if ( word.compareToIgnoreCase( get( i + 1 ) ) < 0
            || ( word.compareToIgnoreCase( get( i + 1 ) ) < 0
                && word.compareToIgnoreCase( get( i - 1 ) ) > 0 ) )
        {
            return super.set( i, word );
        }
        else
        {
            throw new IllegalArgumentException( "word =" + word + " i =" + i );
        }
    }


    /**
     * @param i
     *            is index
     * @param word
     *            is string
     * 
     */
    public void add( int i, String word )
    {

        if ( ( i > 0 && word.compareToIgnoreCase( get( i - 1 ) ) <= 0 )
            || ( i < size() - 1
                && word.compareToIgnoreCase( get( i + 1 ) ) >= 0 ) )
        {
            throw new IllegalArgumentException( "word =" + word + " i =" + i );
        }

        super.add( i, word );
    }


    /**
     * @param word
     *            is string
     * 
     * @return false if word there or adding not successful true if added
     */
    public boolean add( String word )
    {
        if ( contains( word ) )
        {
            return false;
        }

        int left = 0;
        int right = size();

        while ( left < right )
        {
            int middle = ( left + right ) / 2;

            if ( word.compareToIgnoreCase( get( middle ) ) < 0 )
            {
                right = middle;
            }
            else if ( word.compareToIgnoreCase( get( middle ) ) > 0 )
            {
                left = middle + 1;
            }
            else
            {
                return false;
            }
        }

        super.add( right, word );

        return true;
    }


    /**
     * 
     * merges the SortedWordList
     * 
     * @param myList
     *            is the list to be merged with
     */
    public void merge( SortedWordList myList )
    {
        for ( String s : myList )
        {
            add( s );
        }
    }

}