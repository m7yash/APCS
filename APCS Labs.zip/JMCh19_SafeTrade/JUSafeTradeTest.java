import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.regex.*;

import org.junit.*;

import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;


/**
 * SafeTrade tests: TradeOrder PriceComparator Trader Brokerage StockExchange
 * Stock
 *
 * @author Yash Mishra
 * @version 4/19/20
 * @author Assignment: JM Chapter 19 - SafeTrade
 * 
 * @author Sources: none
 *
 */
public class JUSafeTradeTest
{
    // --Test TradeOrder
    /**
     * TradeOrder tests: TradeOrderConstructor - constructs TradeOrder and then
     * compare toString TradeOrderGetTrader - compares value returned to
     * constructed value TradeOrderGetSymbol - compares value returned to
     * constructed value TradeOrderIsBuy - compares value returned to
     * constructed value TradeOrderIsSell - compares value returned to
     * constructed value TradeOrderIsMarket - compares value returned to
     * constructed value TradeOrderIsLimit - compares value returned to
     * constructed value TradeOrderGetShares - compares value returned to
     * constructed value TradeOrderGetPrice - compares value returned to
     * constructed value TradeOrderSubtractShares - subtracts known value &
     * compares result returned by getShares to expected value
     */
    private String symbol = "GGGL";

    private boolean buyOrder = true;

    private boolean marketOrder = true;

    private int numShares = 123;

    private int numToSubtract = 24;

    private double price = 123.45;

    @Test
    public void tradeOrderConstructor()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        String toStr = to.toString();

        assertTrue( "<< Invalid TradeOrder Constructor >>",
            toStr.contains( "TradeOrder[Trader trader:null" )
                && toStr.contains( "java.lang.String symbol:" + symbol )
                && toStr.contains( "boolean buyOrder:" + buyOrder )
                && toStr.contains( "boolean marketOrder:" + marketOrder )
                && toStr.contains( "int numShares:" + numShares )
                && toStr.contains( "double price:" + price ) );
    }


    @Test
    public void TradeOrderToString()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        assertNotNull( to.toString() );
    }


    @Test
    public void tradeOrderGetTrader()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        assertNull( "<< TradeOrder: " + to.getTrader() + " should be null >>",
            to.getTrader() );
    }


    @Test
    public void tradeOrderGetSymbol()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        assertEquals( "<< TradeOrder: " + to.getTrader() + " should be "
            + symbol + " >>", symbol, to.getSymbol() );
    }


    @Test
    public void tradeOrderIsBuy()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );

        assertTrue(
            "<< TradeOrder: " + to.isBuy() + " should be " + buyOrder + " >>",
            to.isBuy() );
    }


    @Test
    public void tradeOrderIsSell()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        assertFalse(
            "<< TradeOrder: " + to.isSell() + " should be " + !buyOrder
                + " >>",
            to.isSell() );
    }


    @Test
    public void tradeOrderIsMarket()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        assertTrue(
            "<< TradeOrder: " + to.isMarket() + " should be " + marketOrder
                + " >>",
            to.isMarket() );
    }


    @Test
    public void tradeOrderIsLimit()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );

        assertFalse(
            "<< TradeOrder: " + to.isLimit() + " should be " + !marketOrder
                + ">>",
            to.isLimit() );
    }


    @Test
    public void tradeOrderGetShares()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        assertTrue(
            "<< TradeOrder: " + to.getShares() + " should be " + numShares
                + ">>",
            numShares == to.getShares()
                || ( numShares - numToSubtract ) == to.getShares() );
    }


    @Test
    public void tradeOrderGetPrice()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        assertEquals( "<< TradeOrder: " + to.getPrice() + " should be " + price
            + ">>", price, to.getPrice(), 0.0 );
    }


    @Test
    public void tradeOrderSubtractShares()
    {
        TradeOrder to = new TradeOrder( null,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price );
        to.subtractShares( numToSubtract );
        assertEquals(
            "<< TradeOrder: subtractShares(" + numToSubtract + ") should be "
                + ( numShares - numToSubtract ) + ">>",
            numShares - numToSubtract,
            to.getShares() );
    }


    // --Test TraderWindow Stub
    @Test
    public void traderWindowConstructor()
    {
        TraderWindow tw = new TraderWindow( null );
        assertNotNull( tw );
    }


    @Test
    public void traderWindowShowMessage()
    {
        TraderWindow tw = new TraderWindow( null );
        assertNotNull( tw );
        tw.showMessage( null );
    }

    // --Test PriceComparator


    @Test
    public void priceComparatorFirstConstructor()
    {
        PriceComparator pc = new PriceComparator();
        assertNotNull( pc );
    }


    @Test
    public void priceComparatorSecondConstructor()
    {
        PriceComparator pc = new PriceComparator( false );
        assertNotNull( pc );
    }

    // --Test Trader


    @Test
    public void traderConstructor()
    {
        Trader t = new Trader( new Brokerage( new StockExchange() ),
            "Trader1",
            "1000" );
        assertNotNull( t );
    }


    @Test
    public void traderToString()
    {
        Trader t = new Trader( new Brokerage( new StockExchange() ),
            "Trader1",
            "1000" );
        assertNotNull( t.toString() );
    }


    @Test
    public void traderCompareTo()
    {
        Trader t1 = new Trader( new Brokerage( new StockExchange() ),
            "Trader1",
            "2227" );
        Trader t2 = new Trader( new Brokerage( new StockExchange() ),
            "Trader2",
            "7222" );
        assertEquals(
            "<< Trader: " + t1.getName() + " compareTo ( " + t2.getName()
                + " ) should be "
                + t1.getName().compareToIgnoreCase( t2.getName() ) + " >>",
            t1.compareTo( t2 ),
            -1 );
    }


    @Test
    public void traderQuit()
    {
        Brokerage myBro = new Brokerage( new StockExchange() );
        Trader t = new Trader( myBro, "T", "1000" );
        myBro.addUser( "T", "1000" );
        myBro.login( "T", "1000" );
        t.quit();
        int size = myBro.getLoggedTraders().size();
        assertEquals( size, 0 );
    }


    @Test
    public void traderGetQuote()
    {
        StockExchange s = new StockExchange();
        s.listStock( symbol, "Trader", price );
        Brokerage myBro = new Brokerage( s );
        Trader t = new Trader( myBro, "Trader1", "1000" );
        t.getQuote( symbol );
        assertTrue(
            "<< Trader: getQuote( " + symbol + " ) should be "
                + t.mailbox().peek() + " >>",
            t.hasMessages() );
    }


    @Test
    public void traderPlaceOrder()
    {
        StockExchange s = new StockExchange();
        s.listStock( symbol, "Trader", price );
        Brokerage myBro = new Brokerage( s );
        Trader t = new Trader( myBro, "Trader1", "1000" );
        t.placeOrder( new TradeOrder( t,
            symbol,
            buyOrder,
            marketOrder,
            numShares,
            price ) );
        assertTrue(
            "<< Trader: placeOrder( " + symbol + " ) should be " + true
                + " >>",
            t.hasMessages() );
    }


    @Test
    public void traderGetName()
    {
        StockExchange s = new StockExchange();
        Brokerage myBro = new Brokerage( s );
        Trader t = new Trader( myBro, "Trader1", "1000" );
        assertEquals( "<< Trader: " + t.getName() + " should be Trader1 >>",
            t.getName(),
            "Trader1" );
    }


    @Test
    public void traderGetPassword()
    {
        StockExchange s = new StockExchange();
        Brokerage myBro = new Brokerage( s );
        Trader t = new Trader( myBro, "Trader1", "1000" );
        assertEquals( "<< Trader: " + t.getPassword() + " should be 1000 >>",
            t.getPassword(),
            "1000" );
    }


    @Test
    public void traderHasMessages()
    {
        StockExchange s = new StockExchange();
        Brokerage myBro = new Brokerage( s );
        Trader t = new Trader( myBro, "Trader1", "1000" );
        assertTrue(
            "<< Trader: " + t.mailbox().size() + " should be " + 0 + " >>",
            t.mailbox().isEmpty() );
    }


    @Test
    public void traderReceiveMessage()
    {
        StockExchange s = new StockExchange();
        Brokerage myBro = new Brokerage( s );
        Trader t = new Trader( myBro, "Trader1", "1000" );
        t.receiveMessage( "Test Message!" );
        assertEquals( "<< Trader: " + t.mailbox().peek() + " should be "
            + "Test Message!" + " >>", t.mailbox().remove(), "Test Message!" );
    }

    // --Test Brokerage

    // TODO your tests here

    // --Test StockExchange

    String c = "ibm";

    @Test
    public void stockExchangeListStock()
    {
        StockExchange s = new StockExchange();
        s.listStock( symbol, c, price );
        assertTrue( s.getListedStocks().containsKey( symbol ) );
    }

    @Test
    public void stockExchangeGetQuote()
    {
        StockExchange s = new StockExchange();
        Stock myStock = new Stock( symbol, "ibm", price );
        String myString = myStock.getQuote();
        s.listStock( symbol, c, price );
        assertEquals( myString, s.getQuote( symbol ) );
    }
    
    // TODO your tests here

    // --Test Stock

    // TODO your tests here

    // Remove block comment below to run JUnit test in console
    /*
     * public static junit.framework.Test suite() { return new
     * JUnit4TestAdapter( JUSafeTradeTest.class ); }
     * 
     * public static void main( String args[] ) {
     * org.junit.runner.JUnitCore.main( "JUSafeTradeTest" ); }
     */
}
