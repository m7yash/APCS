import java.lang.reflect.*;
import java.util.*;


/**
 * 
 *  Represents a Stock Exchange
 *
 *  @author  Yash Mishra
 *  @version Apr 19, 2020
 *  @author  Period: 4
 *  @author  Assignment: JMCh19_SafeTrade
 *
 *  @author  Sources: none
 */
public class StockExchange
{
    private Map<String, Stock> listedStocks;

    /**
     * sets listed Stocks to a new HashMap
     */
    public StockExchange()
    {
        listedStocks = new HashMap<String, Stock>();
    }

    /**
     * 
     * returns the quote in the proper formatting
     * @param symbol of the stock
     * @return the quote in the correct format
     */
    public String getQuote( String symbol )
    {
        if ( symbol == null )
        {
            return "";
        }
        Stock s = listedStocks.get( symbol );
        if ( s != null )
        {
            return s.getQuote();
        }
        return symbol + " not found";
    }

    /**
     * 
     * adds the stock to the list of stocks
     * @param symbol of the stock
     * @param name of the stock
     * @param price of the stock
     */
    public void listStock( String symbol, String name, double price )
    {
        if ( symbol == null )
        {
            return;
        }
        listedStocks.put( symbol, new Stock( symbol, name, price ) );
    }

    /**
     * 
     * places the order for execution later on
     * @param order to be placed
     */
    public void placeOrder( TradeOrder order )
    {
        if ( order == null )
        {
            return;
        }
        Stock s = listedStocks.get( order.getSymbol() );
        if ( s != null )
        {
            s.placeOrder( order );
            return;
        }
        String myString = order.getSymbol() + " not found";
        order.getTrader().receiveMessage( myString );
    }


    //
    // The following are for test purposes only
    //
    /**
     * 
     * returns the list of stocks in the map
     * @return the listed stocks
     */
    protected Map<String, Stock> getListedStocks()
    {
        return listedStocks;
    }


    /**
     * <p>
     * A generic toString implementation that uses reflection to print names and
     * values of all fields <em>declared in this class</em>. Note that
     * superclass fields are left out of this implementation.
     * </p>
     * 
     * @return a string representation of this StockExchange.
     */
    public String toString()
    {
        String str = this.getClass().getName() + "[";
        String separator = "";

        Field[] fields = this.getClass().getDeclaredFields();

        for ( Field field : fields )
        {
            try
            {
                str += separator + field.getType().getName() + " "
                    + field.getName() + ":" + field.get( this );
            }
            catch ( IllegalAccessException ex )
            {
                System.out.println( ex );
            }

            separator = ", ";
        }

        return str + "]";
    }
}