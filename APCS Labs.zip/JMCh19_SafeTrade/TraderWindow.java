import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Provides GUI for a trader.
 */
//// Provides stub TraderWindow for a trader for testing.
public class TraderWindow
{
private Trader myTrader;
    
    public TraderWindow( Trader trader )
    {
myTrader = trader;
    }

    public void showMessage( String msg )
    {
    }
} 