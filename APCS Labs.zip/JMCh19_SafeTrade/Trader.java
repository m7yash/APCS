import java.lang.reflect.*;
import java.util.*;


/**
 * 
 * Represents one trader that implements the comparable interface.
 *
 * @author Yash Mishra
 * @version Apr 19, 2020
 * @author Period: 4
 * @author Assignment: JMCh19_SafeTrade
 *
 * @author Sources: none
 */
public class Trader implements Comparable<Trader>
{
    private Brokerage brokerage;

    private String screenName;

    private String password;

    private TraderWindow myWindow;

    private Queue<String> mailbox;

    /**
     * Creates a Trader and defines variables.
     * 
     * @param brokerage
     *            is the brokerage
     * @param name
     *            is the trader's name
     * @param pswd
     *            is the trader's password
     */
    public Trader( Brokerage brokerage, String name, String pswd )
    {
        this.brokerage = brokerage;
        screenName = name;
        password = pswd;
        mailbox = new PriorityQueue<String>();
    }


    /**
     * @param other
     *            trader to compare to
     * @return the difference ignoring case
     */
    public int compareTo( Trader other )
    {
        return screenName.compareToIgnoreCase( other.getName() );
    }


    /**
     * @param other
     *            trader to compare to
     * @return true if the traders are the same
     */
    public boolean equals( Object other )
    {
        return compareTo( (Trader)other ) == 0;
    }


    /**
     * 
     * returns if the mailbox has messages or not
     * 
     * @return true if the mailbox still has messages
     */
    public boolean hasMessages()
    {
        return mailbox.peek() != null;
    }


    /**
     * 
     * opens a window by showing a message
     */
    public void openWindow()
    {
        myWindow = new TraderWindow( this );
        while ( !mailbox.isEmpty() )
        {
            myWindow.showMessage( mailbox.remove() );
        }
    }


    /**
     * 
     * calls brokerage's order if the order is not null
     * 
     * @param order
     *            to be placed
     */
    public void placeOrder( TradeOrder order )
    {
        if ( order == null )
        {
            return;
        }
        brokerage.placeOrder( order );
    }


    /**
     * logs the trader out
     * 
     */
    public void quit()
    {
        brokerage.logout( this );
        myWindow = null;
    }


    /**
     * 
     * adds the message and shows it
     * 
     * @param msg
     *            to be added
     */
    public void receiveMessage( String msg )
    {
        mailbox.add( msg );
        if ( myWindow != null )
        {
            while ( !mailbox.isEmpty() )
            {
                myWindow.showMessage( mailbox.remove() );
            }
        }
    }


    /**
     * 
     * get method for the name
     * 
     * @return the name of the trader
     */
    public String getName()
    {
        return screenName;
    }


    /**
     * 
     * get method for the password
     * 
     * @return the password of the trader
     */
    public String getPassword()
    {
        return password;
    }


    /**
     * 
     * returns the quote of the stock by calling brokerage's getQuote
     * 
     * @param symbol
     *            of the stock
     */
    public void getQuote( String symbol )
    {
        brokerage.getQuote( symbol, this );
    }


    //
    // The following are for test purposes only
    //
    /**
     * 
     * returns the mailbox queue
     * 
     * @return the mailbox
     */
    protected Queue<String> mailbox()
    {
        return mailbox;
    }


    /**
     * <p>
     * A generic toString implementation that uses reflection to print names and
     * values of all fields <em>declared in this class</em>. Note that
     * superclass fields are left out of this implementation.
     * </p>
     * 
     * @return a string representation of this Trader.
     */
    public String toString()
    {
        String str = this.getClass().getName() + "[";
        String separator = "";

        Field[] fields = this.getClass().getDeclaredFields();

        for ( Field field : fields )
        {
            try
            {
                if ( field.getType().getName().equals( "Brokerage" ) )
                {
                    str += separator + field.getType().getName() + " "
                        + field.getName();
                }
                else
                {
                    str += separator + field.getType().getName() + " "
                        + field.getName() + ":" + field.get( this );
                }
            }
            catch ( IllegalAccessException ex )
            {
                System.out.println( ex );
            }

            separator = ", ";
        }

        return str + "]";
    }
}