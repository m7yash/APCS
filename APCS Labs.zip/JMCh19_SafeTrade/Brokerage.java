import java.lang.reflect.*;
import java.util.*;


/**
 * 
 *  Class that represents a brokerage.
 *  
 *  @author  Yash Mishra
 *  @version Apr 19, 2020
 *  @author  Period: 4
 *  @author  Assignment: JMCh19_SafeTrade
 *
 *  @author  Sources: none
 */
public class Brokerage implements Login
{
    private Map<String, Trader> traders;

    private Set<Trader> loggedTraders;

    private StockExchange exchange;

    /**
     * only constructor for Brokerage
     * @param exchange is the exchange the Brokerage is setting to
     */
    public Brokerage( StockExchange exchange )
    {
        this.exchange = exchange;
        loggedTraders = new TreeSet<Trader>();
        traders = new TreeMap<String, Trader>();
    }

    /**
     * adds the user, returns unique error messages
     * @param name is the name of the user
     * @param password is the password of that user
     * @return the error message code
     */
    public int addUser( String name, String password )
    {
        if ( name.length() < 4 || name.length() > 10 )
        {
            return -1;
        }
        else if ( password.length() < 2 || password.length() > 10 )
        {
            return -2;
        }
        else if ( traders.get( name ) != null )
        {
            return -3;
        }
        traders.put( name, new Trader( this, name, password ) );
        return 0;
    }

    /**
     * logs the user into the program
     * @param name is the name of the user
     * @param password is the password of that user
     * @return the error message code
     */
    public int login( String name, String password )
    {
        if ( traders.get( name ) == null )
        {
            return -1;
        }
        if ( !traders.get( name ).getPassword().equals( password ) )
        {
            return -2;
        }
        if ( loggedTraders.contains( traders.get( name ) ) )
        {
            return -3;
        }
        else
        {
            traders.get( name ).receiveMessage( "Welcome to SafeTrade!" );
            traders.get( name ).openWindow();
            loggedTraders.add( traders.get( name ) );
            return 0;
        }
    }

    /**
     * 
     * logs the user out of the program
     * @param trader is the trader being removed from logged traders
     */
    public void logout( Trader trader )
    {
        loggedTraders.remove( trader );
    }

    /**
     * 
     * "recieves" the message based on the symbol
     * @param symbol is the stock symbol
     * @param trader is the trader trading the stock
     */
    public void getQuote( String symbol, Trader trader )
    {
        trader.receiveMessage( exchange.getQuote( symbol ) );
    }

    /**
     * 
     * calls exchange's placeOrder if the order isn't null
     * @param order is the order to be placed
     */
    public void placeOrder(TradeOrder order)
    {
        if (order == null)
        {
            return;
        }
        exchange.placeOrder( order );
    }
    
    
    //
    // The following are for test purposes only
    //
    /**
     * 
     * get method of traders map
     * @return traders
     */
    protected Map<String, Trader> getTraders()
    {
        return traders;
    }

    /**
     * 
     * get method of the logged traders
     * @return logged traders
     */
    protected Set<Trader> getLoggedTraders()
    {
        return loggedTraders;
    }

    /**
     * 
     * get method of the exchange
     * @return the exchange
     */
    protected StockExchange getExchange()
    {
        return exchange;
    }


    /**
     * <p>
     * A generic toString implementation that uses reflection to print names and
     * values of all fields <em>declared in this class</em>. Note that
     * superclass fields are left out of this implementation.
     * </p>
     * 
     * @return a string representation of this Brokerage.
     * 
     */
    public String toString()
    {
        String str = this.getClass().getName() + "[";
        String separator = "";

        Field[] fields = this.getClass().getDeclaredFields();

        for ( Field field : fields )
        {
            try
            {
                str += separator + field.getType().getName() + " "
                    + field.getName() + ":" + field.get( this );
            }
            catch ( IllegalAccessException ex )
            {
                System.out.println( ex );
            }

            separator = ", ";
        }

        return str + "]";
    }
}
