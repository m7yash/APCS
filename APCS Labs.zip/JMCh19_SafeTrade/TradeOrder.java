import java.lang.reflect.*;

/**
 * 
 *  all the information about a stock and buying/selling it
 *
 *  @author  Yash Mishra
 *  @version Apr 19, 2020
 *  @author  Period: 4
 *  @author  Assignment: JMCh19_SafeTrade
 *
 *  @author  Sources: none
 */
public class TradeOrder
{
    private Trader trader;

    private String symbol;

    private boolean buyOrder;

    private boolean marketOrder;

    private int numShares;

    private double price;

    /**
     * 
     * @param trader is the trader trading stocks
     * @param symbol is the symbol of the stock
     * @param buyOrder is the buy order queue
     * @param marketOrder is the marketorder of the stock
     * @param numShares is the number of stock shares
     * @param price is the price of the stock
     */
    public TradeOrder(
        Trader trader,
        String symbol,
        boolean buyOrder,
        boolean marketOrder,
        int numShares,
        double price )
    {
        this.trader = trader;
        this.symbol = symbol;
        this.buyOrder = buyOrder;
        this.marketOrder = marketOrder;
        this.numShares = numShares;
        this.price = price;
    }

    /**
     * 
     * get method of the trader
     * @return the trader
     */
    public Trader getTrader()
    {
        return trader;
    }
    
    /**
     * 
     * get method for the stock symbol
     * @return the symbol
     */
    public String getSymbol()
    {
        return symbol;
    }
    
    /**
     * 
     * checks if it's a buy order or sell
     * @return true if it's buy
     */
    public boolean isBuy()
    {
        return buyOrder;
    }
    
    /**
     * 
     * checks if it's a buy order or sell
     * @return true if it's sell
     */
    public boolean isSell()
    {
        return !buyOrder;
    }
    
    /**
     * 
     * checks if it's a market or limit order
     * @return true if it is market
     */
    public boolean isMarket()
    {
        return marketOrder;
    }
    
    /**
     * 
     * checks if it's a market or limit order
     * @return true of it is limit
     */
    public boolean isLimit()
    {
        return !marketOrder;
    }

    /**
     * 
     * returns the number of shares
     * @return number of stock shares
     */
    public int getShares()
    {
        return numShares;
    }
    
    /**
     * 
     * get method for the stock price
     * @return stock price
     */
    public double getPrice()
    {
        return price;
    }

    /**
     * 
     * subtracts a certain number of shares from the total
     * @param shares to subtract
     */
    public void subtractShares(int shares)
    {
        numShares = numShares - shares;
    }

    //
    // The following are for test purposes only
    //
    /**
     * <p>
     * A generic toString implementation that uses reflection to print names and
     * values of all fields <em>declared in this class</em>. Note that
     * superclass fields are left out of this implementation.
     * </p>
     * 
     * @return a string representation of this TradeOrder.
     */
    public String toString()
    {
        String str = this.getClass().getName() + "[";
        String separator = "";

        Field[] fields = this.getClass().getDeclaredFields();

        for ( Field field : fields )
        {
            try
            {
                str += separator + field.getType().getName() + " "
                    + field.getName() + ":" + field.get( this );
            }
            catch ( IllegalAccessException ex )
            {
                System.out.println( ex );
            }

            separator = ", ";
        }

        return str + "]";
    }
}
