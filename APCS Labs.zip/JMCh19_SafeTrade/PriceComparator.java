/**
 * 
 *  
 *  TODO Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author  Yash Mishra
 *  @version Apr 19, 2020
 *  @author  Period: 4
 *  @author  Assignment: JMCh19_SafeTrade
 *
 *  @author  Sources: none
 */
public class PriceComparator implements java.util.Comparator<TradeOrder>
{
    /**
     * variable for seeing if order1 is greater than order2
     */
    private boolean ascending;
    
    /**
     * constructor that just sets ascending to true by default
     */
    public PriceComparator()
    {
        ascending = true;
    }

    /**
     * constructor that sets ascending's value to input
     * @param asc boolean value that ascending takes
     */
    public PriceComparator( boolean asc )
    {
        ascending = asc;
    }

    /**
     * compares the two tradeorders and returns the cent difference
     * @param order1 is the first tradeorder
     * @param order2 is the second tradeorder
     * @return returns the difference in cents
     */
    public int compare( TradeOrder order1, TradeOrder order2 )
    {
        boolean oneM = order1.isMarket();
        boolean twoM = order2.isMarket();
        boolean oneL = order1.isLimit();
        boolean twoL = order2.isLimit();
        if ( oneM && twoM )
        {
            return 0;
        }
        if ( oneM && twoL )
        {
            return -1;
        }
        if ( oneL && twoM )
        {
            return 1;
        }
        else
        {
            if ( ascending )
            {
                return (int)((order1.getPrice() - order2.getPrice()) * 100);
            }
            else
            {
                return (int)((order2.getPrice() - order1.getPrice()) * 100);
            }
        }
    }
}
