import java.util.*;
import java.lang.reflect.*;
import java.text.DecimalFormat;


/**
 * 
 * Stock class that deals with the quotes and placing & executing orders
 *
 * @author Yash Mishra
 * @version Apr 19, 2020
 * @author Period: 4
 * @author Assignment: JMCh19_SafeTrade
 *
 * @author Sources: none
 */
public class Stock
{
    /**
     * money format used for outputs
     */
    private static DecimalFormat money = new DecimalFormat( "0.00" );

    private String stockSymbol;

    private String companyName;

    private double loPrice;

    private double hiPrice;

    private double lastPrice;

    private int volume;

    private PriorityQueue<TradeOrder> buyOrders;

    private PriorityQueue<TradeOrder> sellOrders;

    /**
     * General stock constructor
     * 
     * @param symbol
     *            is the symbol of the stock
     * @param name
     *            is the name of the stock
     * @param price
     *            is the price the stock is being sold at
     */
    public Stock( String symbol, String name, double price )
    {
        stockSymbol = symbol;
        companyName = name;
        loPrice = price;
        hiPrice = price;
        lastPrice = price;
        volume = 0;
        sellOrders = new PriorityQueue<TradeOrder>( new PriceComparator() );
        buyOrders = new PriorityQueue<TradeOrder>(
            new PriceComparator( false ) );
    }


    /**
     * 
     * returns the stock quote in the proper format
     * 
     * @return stock quote
     */
    public String getQuote()
    {
        String first = companyName + " (" + stockSymbol + ")" + "\n"
            + "Price: " + lastPrice + " hi: " + hiPrice + " lo: " + loPrice
            + " vol: " + volume + "\n";
        String second;
        String third;
        Object sPeek = sellOrders.peek();
        Object bPeek = buyOrders.peek();
        if ( sPeek == null )
        {
            second = "Ask: none";
        }
        else
        {
            second = "Ask: " + sellOrders.peek().getPrice() + " size: "
                + sellOrders.peek().getShares();
        }

        if ( bPeek == null )
        {
            third = "Bid: none";
        }
        else
        {
            third = "Bid: " + buyOrders.peek().getPrice() + " size: "
                + buyOrders.peek().getShares();
        }
        return first + second + " " + third;
    }


    /**
     * 
     * places the order given
     * 
     * @param order
     *            to be placed
     */
    public void placeOrder( TradeOrder order )
    {
        if ( order == null )
        {
            return;
        }
        String s = "";
        boolean buy = order.isBuy();
        // boolean sell = order.isSell();
        boolean market = order.isMarket();
        if ( buy )
        {
            buyOrders.add( order );
            s = "Buy";
        }
        else // if (order.isSell())
        {
            sellOrders.add( order );
            s = "Sell";
        }
        String myString = "";
        myString += "New Order: " + s + " " + stockSymbol + " (" + companyName
            + ")" + "\n" + order.getShares() + " shares at ";
        if ( market )
        {
            myString += "market";
        }
        else
        {
            myString += "$" + money.format( order.getPrice() );
        }
        order.getTrader().receiveMessage( myString );
        executeOrders();
    }


    /**
     * keeps executing all the orders placed until sellorders and buyorders are
     * emptied
     */
    protected void executeOrders()
    {
        while ( !sellOrders.isEmpty() && !buyOrders.isEmpty() )
        {
            double price = 0.0;

            TradeOrder bPeek = buyOrders.peek();
            boolean bMarket = bPeek.isMarket();
            boolean bLimit = bPeek.isLimit();
            TradeOrder sPeek = sellOrders.peek();
            boolean sMarket = sPeek.isMarket();
            boolean sLimit = sPeek.isLimit();

            if ( bMarket && sMarket )
            {
                price = lastPrice;
            }
            else if ( bLimit && sMarket )
            {
                price = bPeek.getPrice();
            }
            else if ( sLimit && bMarket )
            {
                price = sPeek.getPrice();
            }
            else if ( bLimit && sLimit
                && bPeek.getPrice() >= sPeek.getPrice() )
            {
                price = sPeek.getPrice();
            }
            else
            {
                return;
            }

            int amt = 0;
            amt = sPeek.getShares();
            if ( bPeek.getShares() < sPeek.getShares() )
            {
                amt = bPeek.getShares();
            }

            bPeek.subtractShares( amt );
            sPeek.subtractShares( amt );

            if ( bPeek.getShares() == 0 )
            {
                buyOrders.remove();
            }
            if ( sPeek.getShares() == 0 )
            {
                sellOrders.remove();
            }

            if ( price < loPrice )
            {
                loPrice = price;
            }

            if ( price > hiPrice )
            {
                hiPrice = price;
            }

            lastPrice = price;
            volume = volume + amt;

            String exchange = amt + " " + stockSymbol + " at "
                + money.format( price ) + " amt "
                + money.format( price * amt );

            String buyerMessage = "You bought: " + exchange;
            String sellerMessage = "You sold: " + exchange;
            bPeek.getTrader().receiveMessage( buyerMessage );
            sPeek.getTrader().receiveMessage( sellerMessage );

        }
    }
    //
    // The following are for test purposes only
    //


    /**
     * 
     * get method of the stock symbol
     * 
     * @return the stock's symbol
     */
    protected String getStockSymbol()
    {
        return stockSymbol;
    }


    /**
     * 
     * get method for the company's name
     * 
     * @return the company's name
     */
    protected String getCompanyName()
    {
        return companyName;
    }


    /**
     * 
     * get method for the lowest price
     * 
     * @return the low price
     */
    protected double getLoPrice()
    {
        return loPrice;
    }


    /**
     * 
     * get method for the highest price
     * 
     * @return the high price
     */
    protected double getHiPrice()
    {
        return hiPrice;
    }


    /**
     * 
     * get method for the last price of the day
     * 
     * @return the previous price
     */
    protected double getLastPrice()
    {
        return lastPrice;
    }


    /**
     * 
     * get method for the volume
     * 
     * @return the volume of the stock
     */
    protected int getVolume()
    {
        return volume;
    }


    /**
     * 
     * returns the buy order queue
     * 
     * @return buy order queue
     */
    protected PriorityQueue<TradeOrder> getBuyOrders()
    {
        return buyOrders;
    }


    /**
     * 
     * returns the sell order queue
     * 
     * @return sell order queue
     */
    protected PriorityQueue<TradeOrder> getSellOrders()
    {
        return sellOrders;
    }


    /**
     * <p>
     * A generic toString implementation that uses reflection to print names and
     * values of all fields <em>declared in this class</em>. Note that
     * superclass fields are left out of this implementation.
     * </p>
     * 
     * @return a string representation of this Stock.
     */
    public String toString()
    {
        String str = this.getClass().getName() + "[";
        String separator = "";

        Field[] fields = this.getClass().getDeclaredFields();

        for ( Field field : fields )
        {
            try
            {
                str += separator + field.getType().getName() + " "
                    + field.getName() + ":" + field.get( this );
            }
            catch ( IllegalAccessException ex )
            {
                System.out.println( ex );
            }

            separator = ", ";
        }

        return str + "]";
    }
}
