
/**
 * TODO Write a one-sentence summary of your class here. TODO Follow it with
 * additional details about its purpose, what abstraction it represents, and how
 * to use it.
 *
 * @author: Yash Mishra
 * @version: 08/21/19
 * @author Period: 4th
 * @author Assignment: JMCh02_Hello - HelloWorld.java
 *
 * @author Sources: none
 */
public class HelloWorld
{
    public static void main( String[] args )
    {
        System.out.println( "Hello, World!" );
    }
}
