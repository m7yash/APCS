import java.awt.Color;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;
import info.gridworld.actor.Flower;


/**
 * runs the jumper class with a main method
 *
 * @author Yash Mishra, Roy Long
 * @version 10/25/19
 * @author Period: 4
 * @author Assignment: GridWorld_Part3_Jumper
 *
 * @author Sources: 
 */
public class JumperRunner
{
    public static void main( String[] args )
    {
        // TODO complete main

        ActorWorld world = new ActorWorld();
        Jumper alice = new Jumper();
        alice.setColor( Color.ORANGE );
        Jumper bob = new Jumper();
        world.add( new Location( 7, 7 ), alice );
        world.add( new Location( 5, 5 ), bob );
        world.add( new Rock() );
        world.show();

    }
}