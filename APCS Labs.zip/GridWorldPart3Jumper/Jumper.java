import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Grid;
import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;


/**
 * A <code>Jumper</code> is an actor that will jump over Rocks and Flowers and
 * turn. A jumper can remove another jumper by jumping on them.
 * 
 * @author Yash Mishra, Roy Long
 * @version 10/25/19
 * @author Period: 4
 * @author Assignment: GridWorld_Part3_Jumper
 * 
 * @author Sources: 
 */
public class Jumper extends Actor implements Edible
{
    
    /**
     * 
     * sees if jumper can move by checking next two spaces
     * @return true if can move and false if cannot move
     */
    
    public boolean canMove()
    {
        Grid<Actor> grid = getGrid();

        Location next = getLocation().getAdjacentLocation( getDirection() );

        Location next2 = next.getAdjacentLocation( getDirection() );

        if ( !grid.isValid( next2 ) )
        {
            return false;
        }

        if ( ( grid.get( next2 ) instanceof Edible )
            || grid.get( next2 ) == null )
            return true;

        return false;
    }
    
    /**
     * moves the jumper or turns it
     */
    
    public void act()
    {

        if ( canMove() )
        {
            move();
        }
        else
        {
            turn();
        }
    }


    /**
     * 
     * turns the jumper, overrides turn method
     */
    
    public void turn()
    {
        setDirection( getDirection() + Location.HALF_RIGHT );
    }
    
    /**
     * 
     * moves the jumper, ovverides the move method
     */


    public void move()
    {
        Grid<Actor> gr = getGrid();
        if ( gr == null )
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation( getDirection() );
        Location next2 = next.getAdjacentLocation( getDirection() );
        if ( gr.isValid( next2 ) )
        {
            moveTo( next2 );

        }
    }
}
