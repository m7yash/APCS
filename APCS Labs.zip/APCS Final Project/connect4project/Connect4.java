package connect4project;

import javax.swing.JOptionPane;


/**
 * This is the main class for the project This class is first ran when the
 * player wants to play this game It asks if the player would like to play
 * single player or double player
 *
 * @author Aakash Gupta
 * @version May 26, 2020
 * @author Period: 3
 * @author Assignment: APCS Final Project
 *
 * @author Sources: None
 */
public class Connect4
{
    /**
     * Main method for this class -- It creates a new joptionpane that
     * Determines if the player would like to play with another player or
     * against an AI
     * 
     * @param args
     *            not Used
     */
    public static void main( String[] args )
    {
        int n = JOptionPane.showConfirmDialog( null,
            "Are you playing 2 player",
            "Welcome My Connect 4 Project",
            JOptionPane.YES_NO_OPTION );
        if ( n == 0 )
        {
            new GUIDoublePlayer();
        }
        else if ( n == 1 )
        {
            new GUISinglePlayer();
        }
    }
}
