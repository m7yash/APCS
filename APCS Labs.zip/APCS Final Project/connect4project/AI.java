package connect4project;

/**
 * 
 *  This class represents the AI
 *  This class is created in the Single Player GUI class. It plays the move
 *  for the AI randomly.
 *  
 *
 *  @author  Aakash Gupta
 *  @version May 26, 2020
 *  @author  Period: 3
 *  @author  Assignment: APCS Final Project
 *
 *  @author  Sources: None
 */
public class AI
{
    private int cols;

    private Board myBoard;


    /**
     * The Constructor
     * 
     * @param cols
     *            the number of columns in the board
     */
    public AI( Board board )
    {
        myBoard = board;
        cols = board.getNumCols();
    }


    /**
     * Plays a move for the Computer
     */
    public void playMove()
    {
        boolean isGameOver = myBoard.isGameOver();
        if ( isGameOver )
            return;
        int x = (int)( Math.random() * cols );
        boolean valid = myBoard.Play( 2, x );
        if ( valid )
            return;
        else
        {
            playMove();
        }
    }
}
