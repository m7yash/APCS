package connect4project;

/**
 * This class while represent the board of the game 
 * This class is instantiated in both the GUI classes. It holds what player is
 * in what slot using a 2D int array. It has a lot of methods that help
 * determine what the board looks like
 *
 * @author Aakash Gupta
 * @version May 12, 2020
 * @author Period: 3
 * @author Assignment: APCS Final Project
 *
 * @author Sources: None
 */

public class Board
{
    private int[][] board;

    private boolean isWinner = false;


    /**
     * The constructor of the board -- initialzes the 2D array
     * 
     * @param rows
     *            the number of rows of the board
     * @param cols
     *            the number of columns of the board
     */
    public Board( int rows, int cols )
    {
        board = new int[rows][cols];
        for ( int i = 0; i < board.length; i++ )
        {
            for ( int j = 0; j < board[i].length; j++ )
            {
                board[i][j] = -1;
            }
        }
    }


    /**
     * Returns the int representing the player who's piece is in this square
     * 
     * @param row
     *            the Row
     * @param col
     *            the Col
     * @return 1 if Player1, 2 if AI/Player 2, -1 if this isn't populated
     */
    public int getPlayerAt( int row, int col )
    {
        return board[row][col];
    }


    /**
     * Finds the lowest empty slot for the given column
     * 
     * @param col
     *            the column that the slot goes in
     * @return the lowest row, -1 if the column is full
     */
    private int lowestRow( int col )
    {
        int x;
        for ( x = board.length - 1; x >= 0; x-- )
        {
            if ( board[x][col] == -1 )
            {
                return x;
            }
        }
        return -1;
    }


    /**
     * The number of rows in the board
     * 
     * @return the number of rows in the board
     */
    public int getNumRows()
    {
        return board.length;
    }


    /**
     * The number of columns in the board
     * 
     * @return the number of columns in the board
     */
    public int getNumCols()
    {
        return board[0].length;
    }


    /**
     * This method plays the player into a certain colomn
     * 
     * @param playerNumber
     *            the number of the player who is playing
     * @param col
     *            the col number of what column you want to play in
     * @return true if the play was valid; false otherwise
     */
    public boolean Play( int playerNumber, int col )
    {
        int x = lowestRow( col );
        if ( x == -1 )
        {
            return false;
        }
        else
        {
            board[x][col] = playerNumber;
            return true;
        }
    }


    /**
     * Determines if all the slots have been filled
     * 
     * @return true if all the slots have been filled; false otherwise
     */
    public boolean isGameOver()
    {
        for ( int i = 0; i < board.length; i++ )
        {
            for ( int j = 0; j < board[i].length; j++ )
            {
                if ( board[i][j] == -1 )
                {
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * Determines if a player has won
     * 
     * @param player
     *            the int representation of the player to check has won
     * @return true if player has won; false otherwise
     */
    public boolean isWinner( int player )
    {

        for ( int row = 0; row < board.length; row++ )
        {
            for ( int col = 0; col < board[row].length - 3; col++ )
            {
                if ( board[row][col] == player && board[row][col + 1] == player
                    && board[row][col + 2] == player && board[row][col + 3] == player )
                {
                    isWinner = true;
                    return true;
                }
            }
        }
        for ( int row = 0; row < board.length - 3; row++ )
        {
            for ( int col = 0; col < board[row].length; col++ )
            {
                if ( board[row][col] == player && board[row + 1][col] == player
                    && board[row + 2][col] == player && board[row + 3][col] == player )
                {
                    isWinner = true;
                    return true;
                }
            }
        }
        for ( int row = 3; row < board.length; row++ )
        {
            for ( int col = 0; col < board[row].length - 3; col++ )
            {
                if ( board[row][col] == player && board[row - 1][col + 1] == player
                    && board[row - 2][col + 2] == player && board[row - 3][col + 3] == player )
                {
                    isWinner = true;
                    return true;
                }
            }
        }
        for ( int row = 0; row < board.length - 3; row++ )
        {
            for ( int col = 0; col < board[row].length - 3; col++ )
            {
                if ( board[row][col] == player && board[row + 1][col + 1] == player
                    && board[row + 2][col + 2] == player && board[row + 3][col + 3] == player )
                {
                    isWinner = true;
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * Determines if the current game is a tie
     * 
     * @return true if the game is a tie, false otherwise
     */
    public boolean isTie()
    {
        return isGameOver() && !isWinner;
    }

}
