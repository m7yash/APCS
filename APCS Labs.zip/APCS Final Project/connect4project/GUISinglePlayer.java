package connect4project;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;


/**
 * This class creates the GUI for a Connect 4 game between 1 player and the AI
 * The purpose of this class is to be created when the person selects "1 Play
 * Mode". It is the GUI of the project, and holds the displaying information
 *
 * @author Aakash Gupta
 * @version May 12, 2020
 * @author Period: 3
 * @author Assignment: APCS Final Project
 *
 * @author Sources: None
 */
public class GUISinglePlayer
{
    private JFrame frame;

    private JLabel[][] slots;

    private JButton[] buttons;

    private Board myBoard;

    private AI myAI;

    private int rows = 6;

    private int cols = 7;

    /**
     * Constructs the GUI
     */
    public GUISinglePlayer()
    {
        myBoard = new Board( rows, cols );
        myAI = new AI( myBoard );
        frame = new JFrame( "Connect 4 Black's Turn" );
        slots = new JLabel[rows][cols];
        buttons = new JButton[cols];
        JPanel panel = (JPanel)frame.getContentPane();
        panel.setLayout( new GridLayout( rows + 1, cols ) );
        for ( int i = 0; i < buttons.length; i++ )
        {
            buttons[i] = new JButton( Integer.toString( i + 1 ) );
            buttons[i].setActionCommand( "" + i );
            buttons[i].addActionListener( new ActionListener()
            {

                public void actionPerformed( ActionEvent e )
                {
                    boolean sucess = myBoard.Play( 1, Integer.parseInt( e.getActionCommand() ) );
                    if ( !sucess )
                    {
                        JOptionPane.showMessageDialog( null,
                            "choose another one",
                            "column is filled",
                            JOptionPane.INFORMATION_MESSAGE );
                        return;
                    }
                    displayBoard();
                    if ( myBoard.isWinner( 1 ) )
                    {
                        displayWinner( 1 );
                    }
                    else
                    {
                        myAI.playMove();
                        displayBoard();
                        if ( myBoard.isWinner( 2 ) )
                        {
                            displayWinner( 2 );
                        }
                    }
                    if ( myBoard.isTie() )
                    {
                        displayTie();
                    }
                }
            } );
            panel.add( buttons[i] );
        }

        for ( int row = 0; row < rows; row++ )
        {
            for ( int column = 0; column < cols; column++ )
            {
                slots[row][column] = new JLabel();
                slots[row][column].setHorizontalAlignment( SwingConstants.CENTER );
                slots[row][column].setBorder( new LineBorder( Color.black ) );
                panel.add( slots[row][column] );
            }
        }

        frame.setContentPane( panel );
        frame.setSize( 700, 600 );
        frame.setVisible( true );
        frame.setLocationRelativeTo( null );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    }


    /**
     * Displays the board and the piece in the board. The pieces of the board
     * are represented by the field "myBoard"
     */
    private void displayBoard()
    {
        for ( int i = 0; i < slots.length; i++ )
        {
            for ( int j = 0; j < slots[i].length; j++ )
            {
                switch ( myBoard.getPlayerAt( i, j ) )
                {
                    case -1:
                    {
                        break;
                    }
                    case 1:
                    {
                        slots[i][j].setOpaque( true );
                        slots[i][j].setBackground( Color.BLACK );
                        break;
                    }
                    case 2:
                    {
                        slots[i][j].setOpaque( true );
                        slots[i][j].setBackground( Color.RED );
                    }
                }

            }
        }
    }


    /**
     * This method creates a box that displays that either player 1 or the AI
     * has won. It also asks for a new game.
     * 
     * @param playerWon
     *            The int representation for the player who won the game
     */
    private void displayWinner( int player )
    {
        String winner = "You have lost";
        if ( player == 1 )
        {
            winner = "You have won!!!";
        }
        int n = JOptionPane
            .showConfirmDialog( frame, "new game?", winner, JOptionPane.YES_NO_OPTION );
        if ( n < 1 )
        {
            frame.dispose();
            Connect4.main( null );
        }
        else
        {
            System.exit( 0 );
        }
    }


    /**
     * This method creates a box that displays that the game is a tie. It also
     * asks if the player wants a new game.
     */
    private void displayTie()
    {
        String winner = "Tie Game";
        int n = JOptionPane
            .showConfirmDialog( frame, "new game?", winner, JOptionPane.YES_NO_OPTION );
        if ( n < 1 )
        {
            frame.dispose();
            Connect4.main( null );
        }
        else
        {
            System.exit( 0 );
        }
    }

}
