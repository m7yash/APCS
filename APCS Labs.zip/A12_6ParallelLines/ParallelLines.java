import java.awt.*;
import javax.swing.*;


/**
 * ParallelLines creates a cool illusion with squares and lines
 * 
 * @author Yash Mishra
 * @version 9/23/19
 * 
 *          Period - 4 Assignment - A12.6 - ParallelLines
 * 
 *          Sources - none
 */
public class ParallelLines extends JPanel
{
    public int X_OFFSET = 20;

    public int SQUARE_SIDE = 50;

    public int X_INITIAL = 15;

    public int Y_INITIAL = 40;


    public void paintComponent( Graphics g )
    {
        super.paintComponent( g ); // Call JPanel's paintComponent method
                                   // to paint the background

        int width = getWidth();
        int height = getHeight();

        drawIllusion( g, width, height );
    }


    /**
     * @param g
     *            graphics parameter
     * @param width
     *            of square
     * @param height
     *            of square
     */
    public void drawIllusion( Graphics g, int width, int height )
    {
        for ( int row = 0; row < 8; row++ )
        {
            int x = 0;
            if ( row % 4 == 1 || row % 4 == 3 )
            {
                x = X_INITIAL + X_OFFSET;
            }
            else if ( row % 4 == 2 )
            {
                x = X_INITIAL + 2 * X_OFFSET;
            }
            else if ( row % 4 == 0 )
            {
                x = X_INITIAL;
            }

            for ( int col = 0; col < 7; col++ )
            {
                g.fillRect( x + 2 * col * SQUARE_SIDE,
                    Y_INITIAL + row * SQUARE_SIDE,
                    SQUARE_SIDE,
                    SQUARE_SIDE );
                g.drawLine( X_INITIAL,
                    Y_INITIAL + SQUARE_SIDE * row,
                    X_OFFSET + 14 * SQUARE_SIDE,
                    Y_INITIAL + SQUARE_SIDE * row);
            }
        }
    }


    public static void main( String[] args )
    {
        JFrame w = new JFrame( "ParallelLines" );
        w.setBounds( 100, 100, 640, 480 );
        w.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        ParallelLines panel = new ParallelLines();
        panel.setBackground( Color.WHITE );
        Container c = w.getContentPane();
        c.add( panel );
        w.setResizable( true );
        w.setVisible( true );
    }
}
