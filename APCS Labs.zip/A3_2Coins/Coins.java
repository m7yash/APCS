import java.lang.reflect.Field;
import java.util.Scanner;


/**
 * Coins: This class accepts a certain amount of monetary change (in cents). The
 * output is a list of the number of quarters, dimes, nickels, and pennies that
 * will make that amount of change with the least number of coins possible.
 *
 * @author Yash Mishra
 * @version 9/3/19
 * @author Period: 4
 * 
 * @author Assignment: Lab Activity 3.2 - Coins
 * 
 * @author Sources: none
 */
public class Coins
{
    private int myChange;


    /**
     * constructs a Coins object which converts a given change to the
     * corresponding coins
     * 
     * @param change the inputted number of coins
     */
    public Coins( int change )
    {
        myChange = change;
    }


    /**
     * converts myChange into 4 different types of coins and prints them to the
     * console
     */
    public void calculate()
    {
        int change = myChange;
        int numQuarters = change / 25;
        change = change - numQuarters * 25;
        int numDimes = change / 10;
        change = change - numDimes * 10;
        int numNickels = change / 5;
        change = change - numNickels * 5;
        int numPennies = change;
        change = change - numPennies;
        System.out.println( "Quarters:" + numQuarters );
        System.out.println( "Dimes: " + numDimes );
        System.out.println( "Nickels: " + numNickels );
        System.out.println( "Pennies: " + numPennies );
    }


    /**
     * Intended only for debugging.
     * 
     * <p>
     * A generic toString implementation that uses reflection to print names and
     * values of all fields <em>declared in this class</em>. Note that
     * superclass fields are left out of this implementation.
     * </p>
     * 
     * @return a string representation of this Easter.
     */
    public String toString()
    {
        String str = this.getClass().getName() + "[";
        String separator = "";

        Field[] fields = this.getClass().getDeclaredFields();

        for ( Field field : fields )
        {
            try
            {
                str += separator + field.getType().getName() + " " + 
            field.getName() + ":"
                    + field.get( this );
            }
            catch ( IllegalAccessException ex )
            {
                System.out.println( ex );
            }
            separator = ", ";
        }
        return str + "]";
    }


    /**
     * Tester for the Coins class.
     * 
     * @param args
     *            command line arguments - not used
     */
    public static void main( String[] args )
    {
        Scanner console = new Scanner( System.in );

        System.out.print( "Please enter the number of cents --> " );
        int cents = console.nextInt();

        Coins change = new Coins( cents );
        change.calculate();
    }
}
