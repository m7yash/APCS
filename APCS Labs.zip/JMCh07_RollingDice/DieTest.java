// TODO comments
public class DieTest
{
  public static void main(String[] args)
  {
    // TODO your test code goes here
  }
}
