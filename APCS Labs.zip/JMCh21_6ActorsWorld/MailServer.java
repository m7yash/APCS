import java.util.*;


/**
 * TODO Write a one-sentence summary of your class here. TODO Follow it with
 * additional details about its purpose, what abstraction it represents, and how
 * to use it.
 * 
 * @author Yash Mishra
 * @version 1/24/2020
 * 
 * @author Period - 4
 * @author Assignment - Actors World
 * 
 * @author Sources - 
 */
public class MailServer extends LinkedList<Message>
{
    private Set<Actor> actors;

    // TODO complete class

    /**
     * constructor
     */
    public MailServer()
    {
        actors = new TreeSet<Actor>();
    }

/**
 * 
 * adds an actor
 * @param actor to be added
 */
    public void signUp( Actor actor )
    {
        actors.add( actor );
    }

/**
 * 
 * dispatches a message
 * @param msg to dispatch
 */
    public void dispatch( Message msg )
    {
        Actor gR = msg.getRecipient();
        Actor gS = msg.getSender();
        if ( gR != null )
        {
            gR.receive( msg );
        }
        else
        {
            for ( Actor actor : actors )
            {
                if ( !actor.equals( gS ) )
                {
                    actor.receive( msg );
                }
            }
        }
    }


    // for testing purposes only
    /**
     * 
     * get method for actors since it's private
     * @return actors
     */
    protected Set<Actor> getActors()
    {
        return actors;
    }
}
