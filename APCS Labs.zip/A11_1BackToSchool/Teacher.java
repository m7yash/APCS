// TODO add comments

/**
 * 
 * creates a teacher profile
 *
 * @author Yash Mishra
 * @version Oct 19, 2019
 * @author Period: 4
 * @author Assignment: A11_1BackToSchool
 *
 * @author Sources: none
 */
public class Teacher extends Person
{
    // TODO instance variables

    private String mySubject;

    private double mySalary;

    // TODO constructor

    /**
     * 
     * @param myName
     *            name of teacher
     * @param myAge
     *            age of teacher
     * @param myGender
     *            gender of teacher
     * @param subject
     *            subject that teacher teaches
     * @param salary
     *            salary of the teacher
     */

    public Teacher(
        String myName,
        int myAge,
        String myGender,
        String subject,
        double salary )
    {
        super( myName, myAge, myGender );

        mySubject = subject;
        mySalary = salary;

    }

    // TODO methods


    /**
     * 
     * sets mySubject to input
     * 
     * @param subject
     *            is inputted subject
     */

    public void setSubject( String subject )
    {
        mySubject = subject;
    }


    /**
     * 
     * sets mySalary to input
     * 
     * @param salary
     *            is inputted salary
     */
    public void setSalary( double salary )
    {
        mySalary = salary;
    }


    /**
     * 
     * returns the set subject
     * 
     * @return the subject
     */
    public String getSubject()
    {
        return mySubject;
    }


    /**
     * 
     * returns the set salary
     * 
     * @return the salary
     */

    public double getSalary()
    {
        return mySalary;
    }


    /**
     * Returns a String representation of this class.
     * 
     * @return private instance data as a String
     */
    public String toString()
    {
        return super.toString() + ", subject: " + mySubject + ", salary: "
            + mySalary;
    }
}
