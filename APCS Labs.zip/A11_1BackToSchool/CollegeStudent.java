// TODO add comments

/**
 * 
 * creates a CollegeStudent profile
 * 
 * @author Yash Mishra
 * @version Oct 19, 2019
 * @author Period: 4
 * @author Assignment: A11_1BackToSchool
 *
 * @author Sources: none
 */
public class CollegeStudent extends Student
{
    // TODO instance variables

    private String myMajor;

    private int myYear;

    // TODO constructor

    /**
     * 
     * @param myName
     *            is the name
     * @param myAge
     *            is the age
     * @param myGender
     *            is the gender
     * @param myIdNum
     *            is the student ID number
     * @param myGPA
     *            is the gpa in decimal form
     * @param year
     *            is the student class year
     * @param major
     *            is the student's major
     */

    public CollegeStudent(
        String myName,
        int myAge,
        String myGender,
        String myIdNum,
        double myGPA,
        int year,
        String major )
    {
        super( myName, myAge, myGender, myIdNum, myGPA );

        myMajor = major;
        myYear = year;
    }

    // TODO methods


    /**
     * 
     * sets myMajor to input
     * 
     * @param major
     *            is inputted major
     */

    public void setMajor( String major )
    {
        myMajor = major;
    }


    /**
     * 
     * sets myYear to input
     * 
     * @param year
     *            is inputted year
     */

    public void setYear( int year )
    {
        myYear = year;
    }


    /**
     * 
     * returns the college student's major
     * 
     * @return the major
     */

    public String getMajor()
    {
        return myMajor;
    }


    /**
     * 
     * returns the college student's class year
     * 
     * @return their year of college
     */

    public int getYear()
    {
        return myYear;
    }


    /**
     * Returns a String representation of this class.
     * 
     * @return private instance data as a String
     */
    public String toString()
    {
        return super.toString() + ", year: " + myYear + ", major: " + myMajor;
    }
}
