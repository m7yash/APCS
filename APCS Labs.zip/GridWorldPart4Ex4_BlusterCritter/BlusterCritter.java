import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;

import java.util.ArrayList;

import java.awt.Color;


/**
 * lightens or darkens a critter
 *
 * @author yash mishra
 * @version 11/12/19
 * @author Period: 4
 * @author Assignment: BlusterCritter - GridWorld Part4 Exercise 4
 *
 * @author Sources:
 */
public class BlusterCritter extends Critter
{
    // TODO instance variable(s)

    private int myCourage;

    /**
     * cretaes blustercritter
     * 
     * @param c
     *            is courage
     */
    public BlusterCritter( int c )
    {
        // TODO complete constructor

        myCourage = c;

    }


    /**
     * gets actors in 2 by 2 grid Postcondition: The state of all actors is
     * unchanged.
     * 
     * @return a list of actors that this critter wishes to process.
     */
    public ArrayList<Actor> getActors()
    {
        Grid<Actor> gr = getGrid();
        ArrayList<Actor> actors = new ArrayList<Actor>();

        // TODO complete method

        Location loc = getLocation();

        int i = loc.getRow() - 2;
        int j;
        int a = loc.getRow() + 3;
        int b = loc.getCol() + 3;

        while ( i < a )
        {
            j = loc.getCol() - 2;
            while ( j < b )
            {
                Location coordinate = new Location( i, j );
                if ( gr.isValid( coordinate ) && gr.get( coordinate ) != null
                    && gr.get( coordinate ) != this )
                {
                    actors.add( gr.get( coordinate ) );
                }
                j++;
            }
            i++;
        }

        System.out.println( actors.size() );
        return actors;

    }


    /**
     * uses for-each loop to counter all critters
     * 
     * @param actors
     *            the actors to be processed
     */
    public void processActors( ArrayList<Actor> actors )
    {
        // TODO complete method

        int critterCounter = 0;

        for ( Actor x : actors )
        {
            if ( x instanceof Critter )
            {
                critterCounter++;
            }
        }

        if ( critterCounter < myCourage )
        {
            lighten();
        }
        else
        {
            darken();
        }
    }


    /**
     * darkens the critter
     */
    private void darken()
    {
        // TODO complete method
        // see act method of flower for example

        Color c = getColor();

        int red = c.getRed();
        int green = c.getGreen();
        int blue = c.getBlue();

        if ( red > 9 )
        {
            red -= 10;
        }

        if ( green > 9 )
        {
            green -= 10;
        }

        if ( blue > 9 )
        {
            blue -= 10;
        }

        setColor( new Color( red, green, blue ) );
    }


    /**
     * lightens the critter
     */
    private void lighten()
    {
        // TODO complete method
        // see act method of flower for example

        Color c = getColor();

        int red = c.getRed();
        int green = c.getGreen();
        int blue = c.getBlue();
        if ( red < 246 )
        {
            red += 10;
        }

        if ( green < 246 )
        {
            green += 10;
        }

        if ( blue < 246 )
        {
            blue += 10;
        }

        setColor( new Color( red, green, blue ) );

    }
}
