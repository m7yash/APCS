/**
 * Student.java
 * 
 * Stores the following information about students grade name (first and last)
 * Lynbrook id
 * 
 */
public class Student implements Comparable
{
    private String lynbrookId;

    private String firstName;

    private String lastName;

    private int grade;

    public Student( String id, String fName, String lName, int g )
    {
        lynbrookId = id;
        firstName = fName;
        lastName = lName;
        grade = g;
    }


    public Student()
    {
        this( "", "", "", 0 );
    }


    /**
     * compares students first by grades, if not, then IDs
     * 
     * @param obj
     * @return comparison between grades or ID
     */
    public int compareTo( Object obj )
    {
        Student o = (Student)obj;
        int g = grade;
        int g2 = o.grade;
        String i = lynbrookId;
        String i2 = o.lynbrookId;
        if ( g - g2 == 0 )
        {
            return i.compareTo( i2 );
        }
        else
        {
            return g - g2;
        }
    }


    public Object clone()
    {
        return new Student( lynbrookId, firstName, lastName, grade );
    }


    public String toString()
    {
        return lynbrookId + " " + firstName + " " + lastName + " " + grade;
    }
}
