/**
 * 
 *  Uses loops to find magic squares
 *  Enter in number of magic squares to calculate
 *
 *  @author  Yash Mishra
 *  @version Sep 22, 2019
 *  @author  Period: 4
 *  @author  Assignment: A12_1FunLoops
 *
 *  @author  Sources: none
 */

public class FunLoops
{
    /**
     * 
     * @param n number of magic squares to be calculated
     */
    public void magicsquare( int n )
    {
        System.out.println( "Magic Squares" );
        int ifLooper = 1;
        long sum = 0;
        int sumLooper = 1;
        for  (int i = 1; ifLooper < n + 1; i++)
        {
            int squared = i * i;
            while (sum <= squared)
            {
                if (sum == squared)
                {
                    System.out.println(ifLooper + ": " + squared);
                    ifLooper = ifLooper + 1;
                }
                sum = sum + sumLooper;
                sumLooper = sumLooper + 1;
            }
        }
    }

    /**
     * 
     * @param a first number for the lcm function
     * @param b second number for the lcm function
     * @return the least common multiple
     */
    public int lcm( int a, int b )
    {
        // note: LCM is product divided by greatest common factor
        int gcf;
        int lcm;
        int n1 = a;
        int n2 = b;
        while ( n1 != n2 )
        {
            if ( n1 > n2 )
            {
                n1 = n1 - n2;
            }
            else
            {
                n2 = n2 - n1;
            }
        }
        gcf = n1;
        lcm = a * b / gcf;
        return lcm;
    }

/**
 * 
 * @param args for the program to run
 */
    public static void main( String[] args )
    {
        FunLoops fun = new FunLoops();

        fun.magicsquare( 4 );
        System.out.println();

        System.out.println( "LCM (15, 18) = " + fun.lcm( 15, 18 ) );
        System.out.println( "LCM (40, 12) = " + fun.lcm( 40, 12 ) );
        System.out.println( "LCM (2, 7) = " + fun.lcm( 2, 7 ) );
        System.out.println( "LCM (100, 5) = " + fun.lcm( 100, 5 ) );
        System.out.println();

        fun.magicsquare( 13 );
    }
}
