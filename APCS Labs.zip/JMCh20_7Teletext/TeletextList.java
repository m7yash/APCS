// Implements the list of messages for teletext

import java.awt.Graphics;
import java.util.LinkedList;


/**
 * 
 * TODO Write a one-sentence summary of your class here. TODO Follow it with
 * additional details about its purpose, what abstraction it represents, and how
 * to use it.
 *
 * @author mishr
 * @version Jan 7, 2020
 * @author Period: 4
 * @author Assignment: JMCh20_7Teletext
 *
 * @author Sources: none
 */
public class TeletextList
{
    private ListNode2<String> heading;

    private ListNode2<String> topNode;

    /**
     * Creates a circular list of headlines. First creates a circular list with
     * one node, "Today's headlines:". Saves a reference to that node in
     * heading. Adds a node holding an empty string before heading and another
     * node holding an empty string after heading. Appends all the strings from
     * headlines to the list, after the blank line that follows heading,
     * preserving their order. Sets topNode equal to heading.
     * 
     * @param headlines
     *            Strings to add to circular list
     */
    public TeletextList( String[] headlines )
    {
        // TODO complete constructor
        ListNode2<String> nodeA = new ListNode2<String>( "Today's headlines:",
            null,
            null );
        heading = nodeA;
        ListNode2<String> nodeB = new ListNode2<String>( "", null, heading );
        heading.setPrevious( nodeB );
        ListNode2<String> nodeC = new ListNode2<String>( "", heading, null );
        heading.setNext( nodeC );
        ListNode2<String> nodeD = heading.getNext();

        for ( String s : headlines )
        {
            ListNode2<String> nodeE = new ListNode2<String>( s, nodeD, null );
            nodeD.setNext( nodeE );
            nodeD = nodeD.getNext();
        }

        nodeD.setNext( heading.getPrevious() );
        heading.getPrevious().setPrevious( nodeD );
        
        topNode = heading;
    }


    /**
     * Inserts a node with msg into the headlines list after the blank /line
     * that follows heading.
     * 
     * @param msg
     *            String to add to headlines list
     */
    public void insert( String msg )
    {
        // TODO complete method
        ListNode2<String> hNext = heading.getNext();
        topNode = hNext;
        ListNode2<String> twoNext = hNext.getNext();
        hNext.setNext( new ListNode2<String>( msg, hNext, twoNext ) );
        hNext = hNext.getNext().getNext();
        hNext.setPrevious( new ListNode2<String>( msg, hNext, twoNext ) );
    }


    /**
     * Deletes the node that follows topNode from the headlines list, unless
     * that node happens to be heading or the node before or after heading that
     * holds a blank line.
     */
    public void delete()
    {
        // TODO complete method
        ListNode2<String> t = topNode.getNext();
        ListNode2<String> prev = heading.getPrevious();
        ListNode2<String> after = heading.getNext();

        if ( t.equals( heading ) || t.equals( prev ) || t.equals( after ) )
        {
            return;
        }
        else
        {
            ListNode2<String> afterT = topNode.getNext().getNext();
            topNode = after.getNext();

            after.setNext( afterT );
            topNode.setPrevious( afterT );
        }

    }


    /**
     * Scrolls up the headlines list, advancing topNode to the next node.
     */
    public void scrollUp()
    {
        // TODO complete method
        ListNode2<String> afterT = topNode.getNext();
        topNode = afterT;
    }


    /**
     * 
     * Adds a new node with msg to the headlines list before a given node.
     * Returns a referenece to the added node.
     * 
     * @param node
     *            the node
     * @param msg
     *            the string
     * @return the newNode variable
     */
    private ListNode2<String> addBefore( ListNode2<String> node, String msg )
    {
        ListNode2<String> newNode = new ListNode2<String>( msg,
            node.getPrevious(),
            node );
        node.getPrevious().setNext( newNode );
        node.setPrevious( newNode );
        return newNode;
    }


    /**
     * 
     * Adds a new node with msg to the headlines list after a given node.
     * Returns a referenece to the added node.
     * 
     * @param node
     *            the node
     * @param msg
     *            the message
     * @return the toReturn variable
     */
    private ListNode2<String> addAfter( ListNode2<String> node, String msg )
    {
        // TODO complete method
        ListNode2<String> toReturn = new ListNode2<String>( msg,
            node.getPrevious(),
            node );
        node.setNext( toReturn );
        node.getNext().setNext( toReturn );
        return toReturn;
    }


    /**
     * Removes a given node from the list.
     * 
     * @param node
     *            is the node
     */
    private void remove( ListNode2<String> node )
    {
        // TODO complete method
        ListNode2<String> h = heading;
        while ( !h.equals( node ) )
        {
            h = h.getNext();
            if ( h.equals( node ) )
            {
                break;
            }
        }
        ListNode2<String> twoLater = h.getNext().getNext();
        h.getPrevious().setNext( twoLater );
        twoLater.setPrevious( h.getPrevious() );
    }


    /**
     * 
     * Draws nLines headlines in g, starting with topNode at x, y and
     * incrementing y by lineHeight after each headline.
     * 
     * @param g graphics
     * @param x
     *            variable
     * @param y
     *            variable
     * @param lineHeight
     *            the height of the line
     * @param nLines
     *            number of lines
     */
    public void draw( Graphics g, int x, int y, int lineHeight, int nLines )
    {
        ListNode2<String> node = topNode;
        for ( int k = 1; k <= nLines; k++ )
        {
            g.drawString( node.getValue(), x, y );
            y += lineHeight;
            node = node.getNext();
        }
    }


    /**
     * Returns a string representation of this TeletextList.
     * 
     * @return a string representation of this TeletextList.
     */
    public String toString()
    {
        String str = getClass().getName() + "[";
        String separator = "";

        for ( ListNode2<String> node = heading; node
            .getNext() != heading; node = node.getNext() )
        {
            str += ( separator + node.getValue() );
            separator = ", ";
        }

        return str + "]";
    }
}
