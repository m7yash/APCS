/**
 * 
 * creates a named version of a cow, extends the cow superclass
 * 
 * @author mishr
 * @version Oct 26, 2019
 * @author Period: 4
 * @author Assignment: A29_1OldMacDonald
 *
 * @author Sources: none
 */
class NamedCow extends Cow
{
    // TODO complete this class
    private String myName;

    /**
     * 
     * @param name
     *            of cow
     * @param type
     *            of cow
     * @param sound
     *            cow makes
     */
    public NamedCow( String type, String name, String sound )
    {
        super( type, sound );
        myName = name;
    }


    /**
     * 
     * @param name
     *            of cow
     * @param sound
     *            cow makes
     */

    public NamedCow( String name, String sound )
    {
        super( "cow", sound );
        myName = name;
    }


    /**
     * 
     * gets name of cow
     * 
     * @return name
     */

    public String getName()
    {
        return myName;
    }
}
