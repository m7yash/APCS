/**
 * 
 * creates a pig that meets the minimum requirements of the animal interface
 * 
 * @author mishr
 * @version Oct 26, 2019
 * @author Period: 4
 * @author Assignment: A29_1OldMacDonald
 *
 * @author Sources: none
 */
class Pig implements Animal
{
    // TODO complete class
    private String myType;

    private String mySound;

    /**
     * creates a pig
     * 
     * @param type
     *            of pig
     * @param sound
     *            sound of pig
     */

    public Pig( String type, String sound )
    {
        myType = type;
        mySound = sound;
    }


    /**
     * plays the sound
     * 
     * @return sound of the pig
     */

    public String getSound()
    {
        return mySound;
    }


    /**
     * returns the type
     * 
     * @return type of pig
     */

    public String getType()
    {
        return myType;
    }

}