/**
 * 
 * creates oldmacdonald's farm with a cow, chicken, and pig
 * 
 * @author mishr
 * @version Oct 26, 2019
 * @author Period: 4
 * @author Assignment: A29_1OldMacDonald
 *
 * @author Sources: none
 */
class OldMacDonald
{
    /**
     * 
     * creates a cow, chicken, and pig runs the farm class
     * 
     * @param args
     *            arguments
     */

    public static void main( String[] args )
    {
        Cow c = new Cow( "cow", "moo" );
        System.out.println( c.getType() + " goes " + c.getSound() );

        // TODO <your code here>
        Cow myCow = new NamedCow( "bob", "oof" );
        System.out.println( myCow.getName() + " goes " + myCow.getSound()
            + " and is type " + myCow.getType() );

        Chick ch = new Chick( "chicken", "quack" );
        System.out.println( ch.getType() + " goes " + ch.getSound() );

        Pig p = new Pig( "pig", "oink" );
        System.out.println( p.getType() + " goes " + p.getSound() );

        Farm f = new Farm();
        f.animalSounds();
    }
}
