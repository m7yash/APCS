
public interface Edible
{
    int getCaloriesPerServing();
}
