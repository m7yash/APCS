/**
 * 
 * creates a chicken with minimum requirements of animal interface
 *
 * @author mishr
 * @version Oct 26, 2019
 * @author Period: 4
 * @author Assignment: A29_1OldMacDonald
 *
 * @author Sources: none
 */
class Chick implements Animal
{
    // TODO complete class
    private String myType;

    private String mySound;

    private String mySound2;

    /**
     * 
     * @param type
     *            of chicken
     * @param sound
     *            of chicken
     */
    public Chick( String type, String sound )
    {
        myType = type;
        mySound = sound;
    }


    /**
     * 
     * @param type
     *            of chicken
     * @param sound1
     *            of chicken
     * @param sound2
     *            of chicken
     */

    public Chick( String type, String sound1, String sound2 )
    {
        myType = type;
        mySound = sound1;
        mySound2 = sound2;
    }


    /**
     * gets the sound of the chicken
     * 
     * @return a random sound out of the two
     */

    public String getSound()
    {
        if ( Math.random() < 0.5 )
        {
            return mySound;
        }
        else
        {
            return mySound2;
        }
    }


    /**
     * returns the type of chicken
     * 
     * @return type of chicken
     */

    public String getType()
    {
        return myType;
    }

}