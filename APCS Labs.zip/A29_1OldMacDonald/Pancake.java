
public class Pancake implements Edible
{
    private int myCalories = 5;
    
    public int getCaloriesPerServing()
    {
        return myCalories;
    }
}
