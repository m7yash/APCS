
public class Breakfast
{

    private int myTotalCalories = 0;
    
    public int eat (Edible food, int servings)
    {
        myTotalCalories += food.getCaloriesPerServing() * servings;
        return myTotalCalories;
    }
    
    public static void main (String args[])
    {
        Edible x = new Pancake();
        Breakfast y = new Breakfast();
        System.out.println(y.eat(x, 7));
    }
    
}
