/**
 * This is the heapsort class. It has a sort method and a reheapDown method
 * 
 * @author Yash Mishra
 * @version 3.10.20
 * 
 * @author Period - 4
 * @author Assignment - heapsort
 * 
 * @author Sources -
 */
public class Heapsort
{
    // Sorts a[0], ..., a[size-1] in ascending order
    // using the Mergesort algorithm
    public static void sort( double[] a )
    {
        int length = a.length;
        int i = length / 2;
        while ( i >= 1 )
        {
            reheapDown( a, i, length );
            i--;
        }
        while ( length >= 1 )
        {
            double temp = a[0];
            a[0] = a[length - 1];
            a[length - 1] = temp;
            length--;
            reheapDown( a, 1, length );
        }
    }


    // Should be private - made public for testing
    public static void reheapDown( double[] a, int i, int n )
    {
        while ( ( i * 2 - 1 ) < n )
        {
            int location = ( i * 2 ) - 1;
            if ( (( i * 2 ) < n) && (a[i * 2] > a[( i * 2 ) - 1] ))
            {
                location = i * 2;
            }
            else
            {
                location = (i * 2) - 1;
                // System.out.println("here");
            }
            if ( a[i - 1] < a[location] )
            {
                double temp = a[i - 1];
                a[i - 1] = a[location];
                a[location] = temp;
                i = location;
            }
            else
            {
                return;
            }
        }
    }
}