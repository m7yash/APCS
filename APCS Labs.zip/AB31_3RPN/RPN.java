import java.util.*;

/**
 * RPN Calculator
 *
 * @author Yash Mishra
 * @version 1/15/2020
 * @author Period: 4
 * @author Assignment: AB31RPN Calculator
 *
 * @author Sources: 
 */
public class RPN
{
    Scanner scan = new Scanner( System.in );
    
    private Stack<Integer> myStack;
    private Queue<String> myQ;

    /**
     * Constructs an RPN Calculator
     */
    public RPN()
    {
           
        myStack = new Stack<Integer>();
        myQ = new LinkedList<String>();
        // TODO complete constructor
        
    }
    
    /**
     *  **** Used for testing - Do Not Remove ***
     *  
     *  Constructs an RPN Calculator and then redirects the Scanner input
     *  to the supplied string.
     *  
     *  @param console  replaces console input
     */
    public RPN(String console)
    {
        this();
        scan = new Scanner( console );
    }

    /**
     * TODO Write your method description here.
     */
    public void calculate()
    {
        while(scan.hasNext())
        {
            String next = scan.next();
            myQ.add( next );
            if("+-*/".indexOf(next) != -1)
            {
                int x = myStack.pop();
                int y = myStack.pop();
                if (next.contains("+"))
                {
                    myStack.push( add(x, y) );
                }
                if (next.contains("-"))
                {
                    myStack.push( subtract(x, y) );
                }
                if (next.contains("*"))
                {
                    myStack.push( multiply(x, y) );
                }
                if (next.contains("/"))
                {
                    myStack.push( divide(x, y) );
                }
            }
            else if ("1234567890".indexOf( next ) != -1)
            {
                myStack.push( Integer.parseInt( next ) );
            }
            else if (next.contains("q") || next.contains( "Q" ))
            {
                System.out.println(outputer() + "= " + myStack.pop());
            }
        }
    }

    // TODO: additional helper methods 
    public int add (int x, int y)
    {
        return (x + y);
    }
    public int subtract (int x, int y)
    {
        return (y - x);
    }
    public int multiply (int x, int y)
    {
        return (x * y);
    }
    public int divide (int x, int y)
    {
        return (y / x);
    }
    public String outputer()
    {
        String toReturn = "";
        while (!myQ.isEmpty())
        {
            toReturn += myQ.remove() + " ";
        }
        String replaced = "";
        for ( int i = 0; i < toReturn.length(); i++ )
        {
            if ( toReturn.charAt( i ) == 'q' || toReturn.charAt( i ) == 'Q')
            {
                
            }
            else
            {
                replaced += toReturn.charAt( i );
            }
        }
        replaced = replaced.substring( 0, replaced.length() - 1 );
        return replaced;
    }
    
    /**
     * Instantiates an RPN Calculator and invokes it calculate method
     * 
     * @param args  command-line arguments (not used)
     */
    public static void main( String[] args )
    {
        RPN rpn = new RPN();
        rpn.calculate();
    }
}