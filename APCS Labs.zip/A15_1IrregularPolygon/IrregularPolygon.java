
// import java.awt.Color; commented out because webcat is mad at it
import java.awt.geom.*;
import java.util.*;
import gpdraw.*;


/**
 * TODO Write a one-sentence summary of your class here. TODO Follow it with
 * additional details about its purpose, what abstraction it represents, and how
 * to use it.
 *
 * @author Yash Mishra
 * @version 11/7/19
 *
 * @author Period - 4
 * @author Assignment - irregular polygon
 * 
 * @author Sources -
 */
public class IrregularPolygon
{
    private DrawingTool pen; // = new DrawingTool( new SketchPad( 300, 300, 0 )
                            // );

    private ArrayList<Point2D.Double> myPolygon;

    // constuctors

    /**
     * Implements a class IrregularPolygon that contains an array list of
     * Point2D.Double objects.
     */
    public IrregularPolygon()
    {
        myPolygon = new ArrayList<Point2D.Double>();

    }

    // public methods


    /**
     * 
     * adds a point to myPolygon
     * @param aPoint is the point object that will be added
     */
    public void add( Point2D.Double aPoint )
    {
        myPolygon.add( aPoint );
    }


    /**
     * 
     * calculates perimeter of irregular polygon
     * 
     * @return the perimeter
     */
    public double perimeter()
    {
        double perimeter = 0;
        for ( int i = 0; i < myPolygon.size(); i++ )
        {
            if ( i == myPolygon.size() - 1 )
            {
                Point2D.Double mine = myPolygon.get( i );
                double xDistance = ( Math
                    .pow( mine.getX() - myPolygon.get( 0 ).getX(), 2 ) );
                double yDistance = ( Math
                    .pow( mine.getY() - myPolygon.get( 0 ).getY(), 2 ) );
                perimeter += Math.sqrt( xDistance + yDistance );
                break;
            }
            Point2D.Double first = myPolygon.get( i );
            Point2D.Double second = myPolygon.get( i + 1 );
            perimeter += Math
                .sqrt( ( Math.pow( first.getX() - second.getX(), 2 ) )
                    + ( Math.pow( first.getY() - second.getY(), 2 ) ) );
        }
        return perimeter;
    }


    /**
     * 
     * calculates the area of the irregular polygon
     * 
     * @return the area
     */
    public double area()
    {
        double area = 0.0;
        for ( int i = 0; i < myPolygon.size(); i++ )
        {
            if ( i == myPolygon.size() - 1 )
            {
                Point2D.Double mine = myPolygon.get( i );
                area += mine.getX() * myPolygon.get( 0 ).getY();
                break;
            }
            Point2D.Double first = myPolygon.get( i );
            Point2D.Double second = myPolygon.get( i + 1 );
            area += first.getX() * second.getY();
        }
        for ( int i = 0; i < myPolygon.size(); i++ )
        {
            if ( i == myPolygon.size() - 1 )
            {
                Point2D.Double mine = myPolygon.get( i );
                area -= myPolygon.get( 0 ).getX() * mine.getY();
                break;
            }
            Point2D.Double first = myPolygon.get( i );
            Point2D.Double second = myPolygon.get( i + 1 );
            area -= second.getX() * first.getY();
        }

        area = Math.abs( area ) / 2;

        return area;
    }


    /**
     * draws the irregular polygon with pen() tool
     */
    public void draw()
    {
        if ( myPolygon.size() <= 2 )
        {
            return;
        }
        else
        {
            pen.up();
            pen.move( myPolygon.get( 0 ).getX(), myPolygon.get( 0 ).getY() );
            pen.down();
            for ( int i = 1; i < myPolygon.size(); i++ )
            {
                Point2D.Double mine = myPolygon.get( i );
                pen.move( mine.getX(), mine.getY() );
            }
            pen.move( myPolygon.get( 0 ).getX(), myPolygon.get( 0 ).getY() );
        }
    }
}
