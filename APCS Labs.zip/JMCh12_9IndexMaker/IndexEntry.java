import java.util.ArrayList;

/**
 * 
 *  is the individual index entry
 *
 *  @author  mishr
 *  @version Nov 8, 2019
 *  @author  Period: 4
 *  @author  Assignment: JMCh12_9IndexMaker
 *
 *  @author  Sources: 
 */
public class IndexEntry
{
    // TODO instance fields
    private String word;

    private String space = " ";

    private String blank = "";

    private ArrayList<Integer> numsList;

    // Constructs an IndexEntry for a given word
    // (converted to upper case); sets numsList
    // to an empty ArrayList.
    /**
     * sets input to upercase field and is an arraylist constructor
     * 
     * @param word
     *            input
     */
    public IndexEntry( String word )
    {
        // TODO complete constructor
        this.word = word.toUpperCase();

        numsList = new ArrayList<Integer>( 0 );

    }


    // Returns the word of this IndexEntry object.
    /**
     * 
     * gets the word of the indexentry object
     * 
     * @return word
     */
    public String getWord()
    {
        // TODO complete method
        return word; // Fix this!!
    }


    // If num is not already in the list, adds num
    // at the end of this IndexEntry's list
    // of numbers.
    /**
     * 
     * appends num if it is not in the list
     * 
     * @param num
     *            number
     */
    public void add( int num )
    {
        // TODO complete method
        if ( !numsList.contains( num ) )
        {
            numsList.add( num );
        }
    }


    // Converts this IndexEntry into a string in the
    // following format: the word followed by a space, followed by
    // numbers separated by a comma and a space.
    /**
     * outputs with word followed by space and commas
     * @return the stringed version
     */
    public String toString()
    {
        // TODO complete method

        String myString = word + space;

        String myOtherString = blank; // will be the substring

        for ( int i : numsList )
        {
            myString += i + ", ";
        }

        myOtherString = myString.substring( 0, myString.length() - 2 );

        return myOtherString;

    }
}
