import java.util.ArrayList;

/**
 * 
 *  this is the document index
 *  
 *  @author  mishr
 *  @version Nov 8, 2019
 *  @author  Period: 4
 *  @author  Assignment: JMCh12_9IndexMaker
 *
 *  @author  Sources: 
 */
public class DocumentIndex extends ArrayList<IndexEntry>
{

    // Creates an empty DocumentIndex with the default
    // initial capacity.
    /**
     * creates empty DocumentIndex
     */
    public DocumentIndex()
    {
        // TODO complete constructor
        super();

    }


    // Creates an empty DocumentIndex with a given
    // initial capacity.
    /**
     * creates DocumentIndex with set capacity
     * 
     * @param initialCapacity
     *            is the capacity set for DocumentIndex
     */
    public DocumentIndex( int initialCapacity )
    {
        // TODO complete constructor

        super( initialCapacity );

    }


    // If word is not yet in this DocumentIndex,
    // creates a new IndexEntry for word, and inserts
    // it into this list in alphabetical order;
    // adds num to this word's IndexEntry by calling
    // its add(num) method.
    /**
     * 
     * adds a word by calling add(...) method
     * 
     * @param word
     *            is word
     * @param num
     *            is number
     */
    public void addWord( String word, int num )
    {
        // TODO complete method

        get( foundOrInserted( word ) ).add( num );

    }


    // For each word in str, calls addWord(word, num).
    /**
     * 
     * uses addWord (..., ...)
     * 
     * @param str
     *            is the string
     * @param num
     *            is the number
     */
    public void addAllWords( String str, int num )
    {
        // TODO complete method
        
        String blank = "";
        String nonWord = "\\W+";

        String[] myList = str.split( nonWord );

        for ( String myString : myList )
        {
            boolean isEqual = myString.equals(blank);
            if ( !isEqual )
            {
                addWord( myString, num );
            }
        }

    }


    // Tries to find an EndexEntry with a given word in this
    // DocumentIndex. If not found, inserts a new EndexEntry for
    // word at the appropriate place (in lexicographical order).
    // Returns the index of the found or inserted IndexEntry
    /**
     * 
     * returns index and puts in alphabetical order
     * 
     * @param word
     *            input
     * @return index
     */
    private int foundOrInserted( String word )
    {
        // TODO complete method

        for ( int i = 0; i < size(); i++ )
        {

            int myComparison = word.compareToIgnoreCase( get( i ).getWord() );

            boolean theyAreTheSame = myComparison == 0;
            boolean comesFirst = myComparison < 0;

            if ( theyAreTheSame )
            {
                return i;
            }

            if ( comesFirst )
            {
                this.add( i, new IndexEntry( word ) );
                return i;
            }

        }
        add( new IndexEntry( word ) );
        return size() - 1;
    }
}