/**
 * TODO Write a one-sentence summary of your class here. TODO Follow it with
 * additional details about its purpose, what abstraction it represents, and how
 * to use it.
 * 
 * @author Yash
 * @version 10/5/19
 * 
 * @author Period - 4
 * @author Assignment - JMCh10 Lipogrammer
 * 
 * @author Sources - none
 */
public class LipogramAnalyzer
{
    private String text;

    private int lastLetterNum;

    /**
     * Constructor: Saves the text string
     * 
     * @param text
     *            String to analyze
     */
    public LipogramAnalyzer( String text )
    {
        // TODO your constructor code here
        this.text = text;
    }


    /**
     * Returns the text string with all characters equal to letter replaced with
     * '#'.
     * 
     * @param letter
     *            character to replace
     * @return text string with all characters equal to letter replaced with '#'
     */
    public String mark( char letter )
    {
        // TODO your code here
        String replaced = "";
        for ( int i = 0; i < text.length(); i++ )
        {
            if ( text.charAt( i ) == letter )
            {
                replaced += '#';
            }
            else
            {
                replaced += text.charAt( i );
            }
        }
        return replaced;
    }


    /**
     * Returns a String that concatenates all "offending" words from text that
     * contain letter; the words are separated by '\n' characters; the returned
     * string does not contain duplicate words: each word occurs only once;
     * there are no punctuation or whitespace characters in the returned string.
     * 
     * @param letter
     *            character to find in text
     * @return String containing all words with letter
     */
    public String allWordsWith( char letter )
    {
        String result = "\n";
        String word;
        int location = text.indexOf( letter );
        while ( location != -1 )
        {
            word = extractWord( location ) + "\n";

            if ( result.indexOf( "\n" + word ) == -1 )
            {
                result += word;
            }
            location = text.indexOf( letter, lastLetterNum );

        }
        return result.substring( 1, result.length() );
    }


    /**
     * 
     * Returns the word that contains character at pos excluding any punctuation
     * or whitespace.
     * 
     * @param pos
     *            location of character
     * @return word that contains character at pos
     */
    public String extractWord( int pos )
    {
        int start;
        int length = text.length();
        for ( lastLetterNum = pos; lastLetterNum < length
            && ( text.charAt( lastLetterNum ) >= 'A'
                && text.charAt( lastLetterNum ) <= 'Z'
                || text.charAt( lastLetterNum ) >= 'a'
                    && text.charAt( lastLetterNum ) <= 'z' ); lastLetterNum++ )
        {
        }

        for ( start = pos; start > -1
            && ( text.charAt( start ) >= 'A' && text.charAt( start ) <= 'Z'
                || text.charAt( start ) >= 'a'
                    && text.charAt( start ) <= 'z' ); start-- )
        {
        }

        return text.substring( start + 1, lastLetterNum );
    }
}
