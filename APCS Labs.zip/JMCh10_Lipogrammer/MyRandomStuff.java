public class MyRandomStuff
{
    public boolean onlyDigits( String s )
    {
        for (int i = 0; (i <= s.length()) && (Character.isDigit( s.charAt( i ) ) == true); i++ )
        {
            if (i == s.length() - 1)
            {
                return true;
            }
        }
        return false;
    }
    
    public int lengthyee (String x)
    {
        int s = x.length();
        return s;
    }
    
    public int diff (String x, String y)
    {
        int myDifference = x.compareTo(y);
        return myDifference;
    }
    public boolean rando (String s1, String s2)
    {
        if (s1.length() > 0 && s2.length() > 0 && (s1.charAt( s1.length() - 1) == s2.charAt( s2.length() - 1 )))
        {
            
            System.out.println("yee");
            return true;
            
        }
        else
        {
            
            System.out.println("oof");
            return false;
            
        }
    }
    
    public static void main (String args[])
    {
        MyRandomStuff first = new MyRandomStuff();
        System.out.println(first.onlyDigits("12345x"));
        
        MyRandomStuff second = new MyRandomStuff();
        System.out.println(second.diff("dog", "dog"));
        
        MyRandomStuff third = new MyRandomStuff();
        System.out.println(third.rando("hello", "wzefzwef" ));
        
        MyRandomStuff fourth = new MyRandomStuff();
        System.out.println(fourth.lengthyee( "hello test" ));
    }
}

