import java.lang.reflect.*;

/**
   This class implements a vendor that sells one kind of item.
   A vendor carries out sales transactions.

   @author  Yash Mishra
   @version 9/30/19

   @author Period - 4
   @author Assignment - Java Methods Ch09 - SnackBar

   @author Sources - none
 */
public class Vendor
{
    // Fields:
    private static double totalSales = 0.0;
    private int deposit;
    private int price;
    private int change;
    private int stock;

    //getTotalSales method here
    
    /**
     * 
     * This returns the total amount of sales and resets it
     * @return temp is the total amount of sales
     */
    
    public static double getTotalSales()
    {
        double temp = totalSales;
        totalSales = 0.0;
        return temp;
    }
    
    //  Constructor
    //  Parameters:
    //    int price of a single item in cents
    //    int number of items to place in stock
    
    /**
     * 
     * @param price is the price of the item
     * @param stock is the current remaining stock
     */
    
    
    public Vendor(int price, int stock)
    {
        this.price = price;
        this.stock = stock;
    }

    //  Sets the quantity of items in stock.
    //  Parameters:
    //    int number of items to place in stock
    //  Return:
    //    None
    
    /**
     * 
     * sets the stock field to the actual amount of stock left
     * @param numStock is the real amount of stock left
     */
    
    public void setStock(int numStock)
    {
        stock = numStock;
    }

    //  Returns the number of items currently in stock.
    //  Parameters:
    //    None
    //  Return:
    //    int number of items currently in stock
    
    /**
     * 
     * returns the amount of stock left after setStock
     * @return stock the stock field
     */
    
    public int getStock()
    {
        return stock;
    }

    //  Adds a specified amount (in cents) to the deposited amount.
    //  Parameters:
    //    int number of cents to add to the deposit
    //  Return:
    //    None
    
    /**
     * 
     * deposits a certain amount of money
     * @param centsToDeposit increments deposit field
     */
    
    public void addMoney(int centsToDeposit)
    {
        if (stock > 0)
        {
            deposit = deposit + centsToDeposit;            
        }
    }

    //  Returns the currently deposited amount (in cents).
    //  Parameters:
    //    None
    //  Return:
    //    int number of cents in the current deposit
    
    
    /**
     * 
     * takes the current deposit and returns the amount in cents
     * @return deposit currently deposited name
     */
    public int getDeposit()
    {
        return deposit;
    }

    //  Implements a sale.  If there are items in stock and
    //  the deposited amount is greater than or equal to
    //  the single item price, then adjusts the stock
    //  and calculates and sets change and returns true;
    //  otherwise refunds the whole deposit (moves it into change)
    //  and returns false.
    //  Parameters:
    //    None
    //  Return:
    //    boolean successful sale (true) or failure (false)
    
    /**
     * 
     * implements a sale
     * @return true if sale possible or false if impossible
     */
    
    public boolean makeSale()
    {
        if (stock > 0 && deposit >= price)
        {
            stock--;
            double dollarPrice = 0.01 * price;
            totalSales = totalSales + dollarPrice;
            if (deposit != price)
            {
                change = (int)(deposit - price);   
            }
            else
            {
                change = 0;
            }
            deposit = 0;
            return true;
        }
        else
        {
            change = deposit;
            deposit = 0;
            return false;
        }
    }

    //  Returns and zeroes out the amount of change (from the last
    //  sale or refund).
    //  Parameters:
    //    None
    //  Return:
    //    int number of cents in the current change
    
    /**
     * 
     * resets change from last refund
     * @return temp number of cents in current change
     */
    
    
    public int getChange()
    {
        int temp = change;
        change = 0;
        return temp;
    }

    /**
        Intended only for debugging.
        
        <p>A generic toString implementation that uses reflection to print
        names and values of all fields <em>declared in this class</em>.
        Note that superclass fields are left out of this implementation.</p>
        
        @return  a string representation of this Vendor.
     */
    public String toString()
    {
        String str = this.getClass().getName() + "[";
        String separator = "";

        Field[] fields = this.getClass().getDeclaredFields();

        for ( Field field : fields )
        {
            try
            {
                str += separator + field.getName() + ":" + field.get( this );
            }
            catch ( IllegalAccessException ex )
            {
                System.out.println( ex );
            }

            separator = ", ";
        }

        return str + "]";
    }
}
